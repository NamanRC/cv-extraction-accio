"""accio CLI — PDF table extraction, evaluation, and benchmarking."""

import os
import sys
from pathlib import Path
from typing import Optional

import typer

app = typer.Typer(
    name="accio",
    help="PDF table extraction, evaluation, and benchmarking",
    add_completion=False,
)


def _resolve_config(config: str) -> dict:
    from accio.core import load_config

    config_path = Path(config)
    if not config_path.exists():
        typer.echo(f"Config not found: {config_path}", err=True)
        raise typer.Exit(1)
    return load_config(config_path)


@app.command()
def run(
    pdf: Optional[str] = typer.Argument(None, help="PDF file path (omit for batch mode)"),
    config: str = typer.Option("config.yaml", "--config", "-c", help="Config YAML file"),
    llm: Optional[list[str]] = typer.Option(None, "--llm", help="LLM to use (repeatable)"),
    all: bool = typer.Option(False, "--all", "-a", help="Run all available LLMs"),
    consensus: bool = typer.Option(False, "--consensus", help="Build multi-extractor consensus"),
    raw: bool = typer.Option(False, "--raw", help="Print raw extraction output"),
    no_cache: bool = typer.Option(False, "--no-cache", help="Skip cache, force new extraction"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed rich tables for every field"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output directory"),
    output_details: Optional[str] = typer.Option(None, "--output-details", help="Output JSONL for field-level details"),
    ground_truth: Optional[str] = typer.Option(None, "--ground-truth", "-g", help="Ground truth JSON file"),
    parallel: bool = typer.Option(False, "--parallel", "-p", help="Run extractions in parallel"),
):
    """Extract data from PDFs and evaluate against ground truth."""
    from accio.core import run as core_run

    cfg = _resolve_config(config)

    rc = core_run(
        pdf=pdf,
        config=cfg,
        llms=llm or None,
        all_llms=all,
        consensus=consensus,
        raw=raw,
        no_cache=no_cache,
        output=output,
        output_details=output_details,
        ground_truth_path=ground_truth,
        verbose=verbose,
        parallel=parallel,
    )
    raise typer.Exit(rc or 0)


@app.command()
def extract(
    pdf: str = typer.Argument(..., help="PDF file path"),
    config: str = typer.Option("config.yaml", "--config", "-c", help="Config YAML file"),
    llm: str = typer.Option(..., "--llm", help="LLM to use (e.g. gemini/gemini-2.5-flash)"),
    no_cache: bool = typer.Option(False, "--no-cache", help="Skip cache, force new extraction"),
    no_normalize: bool = typer.Option(False, "--no-normalize", help="Skip normalization"),
    no_verify: bool = typer.Option(False, "--no-verify", help="Skip LLM verification"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Write result JSON to this path"),
):
    """Extract data from a single PDF with a single LLM."""
    import json

    import accio

    cfg = _resolve_config(config)

    try:
        result = accio.extract(
            pdf, cfg, llm=llm, no_cache=no_cache,
            normalize=not no_normalize, verify=not no_verify,
        )
    except ValueError as e:
        typer.echo(str(e), err=True)
        raise typer.Exit(1)

    if output:
        with open(output, "w") as f:
            json.dump(result["data"], f, indent=2)
        typer.echo(f"Written to {output}")
    else:
        typer.echo(json.dumps(result["data"], indent=2))

    if result["cost"] > 0:
        typer.echo(f"\nCost: ${result['cost']:.4f}", err=True)


@app.command("list")
def list_llms(
    config: str = typer.Option("config.yaml", "--config", "-c", help="Config YAML file"),
):
    """List available LLMs (based on API keys in environment)."""
    from accio.core import available_llms

    # Load config to trigger dotenv
    if Path(config).exists():
        _resolve_config(config)

    llms = available_llms()
    if not llms:
        typer.echo("No LLMs available. Set API keys: GOOGLE_API_KEY, OPENAI_API_KEY, ANTHROPIC_API_KEY")
        raise typer.Exit(1)

    typer.echo("Available LLMs:")
    for llm in llms:
        typer.echo(f"  {llm}")


@app.command()
def explain(
    config: str = typer.Option("config.yaml", "--config", "-c", help="Config YAML file"),
    llm: Optional[str] = typer.Option(None, "--llm", help="LLM as provider/model (e.g. gemini/gemini-2.5-flash)"),
):
    """Generate explanations for config and write .explain.json."""
    import json

    import yaml

    from accio.llm import PROMPT, generate_text, pick_llm
    from accio.ui.backend.config import sanitize_config

    cfg = _resolve_config(config)
    sanitized = sanitize_config(cfg)
    config_yaml = yaml.dump(sanitized, default_flow_style=False, sort_keys=False)

    if llm:
        parts = llm.split("/", 1)
        if len(parts) != 2:
            typer.echo("--llm must be provider/model (e.g. gemini/gemini-2.5-flash)", err=True)
            raise typer.Exit(1)
        provider, model = parts
    else:
        picked = pick_llm()
        if not picked:
            typer.echo("No LLM API key found. Set GOOGLE_API_KEY, OPENAI_API_KEY, or ANTHROPIC_API_KEY.", err=True)
            raise typer.Exit(1)
        provider, model = picked

    typer.echo(f"Generating explanations with {provider}/{model}...")

    prompt = PROMPT.format(config_yaml=config_yaml)
    text = generate_text(prompt, provider, model)

    text = text.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[1] if "\n" in text else text[3:]
        if text.endswith("```"):
            text = text[:-3]
        text = text.strip()

    result = json.loads(text)

    out_path = Path(config).resolve().parent / ".explain.json"
    with open(out_path, "w") as f:
        json.dump(result, f, indent=2)

    typer.echo(f"Written to {out_path}")


@app.command()
def ui(
    config: str = typer.Option("config.yaml", "--config", "-c", help="Config YAML file"),
    port: int = typer.Option(8000, "--port", "-p", help="Server port"),
    host: str = typer.Option("127.0.0.1", "--host", help="Server host"),
    rebuild: bool = typer.Option(False, "--rebuild", help="Force rebuild the frontend"),
):
    """Launch the evaluation dashboard UI."""
    import shutil
    import subprocess

    import uvicorn

    config_path = Path(config).resolve()
    if not config_path.exists():
        typer.echo(f"Config not found: {config_path}", err=True)
        raise typer.Exit(1)

    frontend_dir = Path(__file__).parent / "ui" / "frontend"
    dist_dir = frontend_dir / "dist"

    if rebuild and dist_dir.exists():
        shutil.rmtree(dist_dir)

    if not dist_dir.exists():
        if not shutil.which("npm"):
            typer.echo("npm not found — required to build the dashboard frontend", err=True)
            raise typer.Exit(1)
        typer.echo("Building frontend (first run)...")
        node_modules = frontend_dir / "node_modules"
        if not node_modules.exists():
            subprocess.run(["npm", "install"], cwd=frontend_dir, check=True)
        subprocess.run(["npm", "run", "build"], cwd=frontend_dir, check=True)
        typer.echo("Frontend built.")

    os.environ["ACCIO_CONFIG"] = str(config_path)

    cors_origins = os.environ.get("CORS_ORIGINS", f"http://localhost:5173,http://127.0.0.1:5173,http://localhost:{port},http://127.0.0.1:{port}")
    os.environ["CORS_ORIGINS"] = cors_origins

    typer.echo(f"Starting dashboard at http://{host}:{port}")
    typer.echo(f"Config: {config_path}")

    uvicorn.run(
        "accio.ui.backend.main:app",
        host=host,
        port=port,
        reload=False,
    )


if __name__ == "__main__":
    app()
