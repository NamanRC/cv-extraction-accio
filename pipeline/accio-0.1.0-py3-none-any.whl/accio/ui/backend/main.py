import csv
import os
import re
from collections import defaultdict
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from accio.ui.backend.config import get_project
from accio.ui.backend.routes import projects, models, documents, pdfs

app = FastAPI(title="accio")

origins = os.environ.get("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in origins],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(projects.router)
app.include_router(models.router)
app.include_router(documents.router)
app.include_router(pdfs.router)

@app.get("/api/health")
def health():
    return {"status": "ok"}


# ── Reference GT (optional secondary ground truth from raw system CSV) ──

_ref_gt_cache = {}


def _classify_serial_fd(value: str) -> tuple[str, str]:
    """Classify a Serial # column value as either serial_number or fd_number.
    Returns (serial_number, fd_number) — one will be empty."""
    if not value or not value.strip():
        return ("", "")
    v = value.strip()
    # Starts with "FD" → FD number
    if re.match(r'^[Ff][Dd]', v):
        return ("", v)
    # Strip non-digits to check length
    digits = re.sub(r'[^0-9]', '', v)
    # 13+ digits → serial number
    if len(digits) >= 13:
        return (v, "")
    # <=12 digits → FD number
    return ("", v)


def _load_reference_gt(project: dict) -> dict:
    """Load reference GT from a raw system CSV (e.g. Ground Truth Untouched.csv).
    Expected columns: External ID (claim ID), Model, Serial #, SellPrice,
    Dealer, Invoice, Date Of Sale, Customer FirstName/LastName/Address1/City/State/ZipCode.
    Drops summary rows (comma-separated Model values)."""
    name = project.get("name", "")
    if name in _ref_gt_cache:
        return _ref_gt_cache[name]

    path_str = project.get("reference_gt")
    if not path_str or not Path(path_str).exists():
        _ref_gt_cache[name] = {}
        return {}

    # First pass: build claim_id → doc_id mapping from outputs directory
    claim_to_docid = {}
    outputs_dir = project.get("outputs", "")
    if outputs_dir:
        outputs_path = Path(outputs_dir)
        if outputs_path.exists():
            for provider_dir in outputs_path.iterdir():
                if not provider_dir.is_dir():
                    continue
                for model_dir in provider_dir.iterdir():
                    if not model_dir.is_dir():
                        continue
                    for f in model_dir.glob("*.json"):
                        doc_id = f.stem
                        claim_id = doc_id.split("_")[0]
                        claim_to_docid[claim_id] = doc_id
                    break  # only need one model dir
                break

    # Parse CSV
    by_doc = defaultdict(lambda: {"claim": {}, "products": []})
    with open(path_str) as f:
        for r in csv.DictReader(f):
            claim_id = r.get("External ID (claim ID)", "").strip()
            model = r.get("Model", "").strip()

            # Skip summary rows (comma-separated models or empty)
            if "," in model or not model:
                # Still use for claim-level fields if not yet set
                doc_id = claim_to_docid.get(claim_id)
                if doc_id and not by_doc[doc_id]["claim"]:
                    first = r.get("Customer FirstName", "").strip()
                    last = r.get("Customer LastName", "").strip()
                    addr1 = r.get("Customer Address1", "").strip()
                    city = r.get("Customer City", "").strip()
                    state = r.get("Customer State", "").strip()
                    zipcode = r.get("Customer ZipCode", "").strip()
                    by_doc[doc_id]["claim"] = {
                        "consumer_first_name": first,
                        "consumer_last_name": last,
                        "consumer_address": ", ".join(p for p in [addr1, city, state, zipcode] if p),
                        "customer_name": f"{first} {last}".strip(),
                        "customer_address": ", ".join(p for p in [addr1, city, state, zipcode] if p),
                        "dealer_name": r.get("Dealer", "").strip(),
                        "invoice_number": r.get("Invoice", "").strip(),
                        "purchase_date": r.get("Date Of Sale", "").strip(),
                    }
                continue

            doc_id = claim_to_docid.get(claim_id)
            if not doc_id:
                continue

            # Set claim-level fields from first product row if not from summary
            if not by_doc[doc_id]["claim"]:
                first = r.get("Customer FirstName", "").strip()
                last = r.get("Customer LastName", "").strip()
                addr1 = r.get("Customer Address1", "").strip()
                city = r.get("Customer City", "").strip()
                state = r.get("Customer State", "").strip()
                zipcode = r.get("Customer ZipCode", "").strip()
                by_doc[doc_id]["claim"] = {
                    "consumer_first_name": first,
                    "consumer_last_name": last,
                    "consumer_address": ", ".join(p for p in [addr1, city, state, zipcode] if p),
                    "customer_name": f"{first} {last}".strip(),
                    "customer_address": ", ".join(p for p in [addr1, city, state, zipcode] if p),
                    "dealer_name": r.get("Dealer", "").strip(),
                    "invoice_number": r.get("Invoice", "").strip(),
                    "purchase_date": r.get("Date Of Sale", "").strip(),
                }

            # Classify Serial # as serial_number or fd_number
            serial_raw = r.get("Serial #", "").strip()
            serial_number, fd_number = _classify_serial_fd(serial_raw)

            by_doc[doc_id]["products"].append({
                "model_number": model,
                "serial_number": serial_number,
                "fd_number": fd_number,
                "sell_price": r.get("SellPrice", "").strip(),
            })

    result = dict(by_doc)
    _ref_gt_cache[name] = result
    return result


@app.get("/api/projects/{project_id}/reference-gt/{doc_id}")
def get_reference_gt(project_id: str, doc_id: str):
    project = get_project(project_id)
    if not project:
        return {"claim": {}, "products": []}
    ref = _load_reference_gt(project)
    return ref.get(doc_id, {"claim": {}, "products": []})


@app.get("/api/projects/{project_id}/accuracy-histogram")
def accuracy_histogram(project_id: str):
    project = get_project(project_id)
    if not project:
        return {"error": "project not found"}
    from accio.ui.backend.services import eval_details
    model_list = eval_details.list_models(project)
    records = eval_details.get_model_records(project, model_list[0]) if model_list else []
    scores = [r.get("accuracy", 0) for r in records]
    total = len(scores)
    avg = sum(scores) / total if total else 0
    bands = [
        {"label": "100%", "lo": 100, "hi": 100.01},
        {"label": "95-99%", "lo": 95, "hi": 100},
        {"label": "90-94%", "lo": 90, "hi": 95},
        {"label": "80-89%", "lo": 80, "hi": 90},
        {"label": "70-79%", "lo": 70, "hi": 80},
        {"label": "60-69%", "lo": 60, "hi": 70},
        {"label": "50-59%", "lo": 50, "hi": 60},
        {"label": "<50%", "lo": 0, "hi": 50},
    ]
    for b in bands:
        b["count"] = sum(1 for s in scores if b["lo"] <= s < b["hi"])
    return {
        "total": total,
        "average": round(avg, 1),
        "perfect": sum(1 for s in scores if s == 100),
        "gte95": sum(1 for s in scores if s >= 95),
        "gte90": sum(1 for s in scores if s >= 90),
        "lt70": sum(1 for s in scores if s < 70),
        "bands": [{"label": b["label"], "count": b["count"]} for b in bands],
    }


@app.get("/api/projects/{project_id}/output/{provider}/{model}/{doc_id}")
def get_output(project_id: str, provider: str, model: str, doc_id: str):
    """Return raw extraction output for a document."""
    import json as _json
    project = get_project(project_id)
    if not project:
        return {"error": "project not found"}
    outputs_dir = project.get("outputs")
    if not outputs_dir:
        return {"error": "no outputs configured"}
    output_path = Path(outputs_dir) / provider / model / f"{doc_id}.json"
    if not output_path.exists():
        return {"error": "output not found"}
    with open(output_path) as f:
        return _json.load(f)


# Serve frontend dist if present — must be last (catches all unmatched routes)
frontend_dist = Path(__file__).parent.parent / "frontend" / "dist"
if frontend_dist.exists():
    app.mount("/", StaticFiles(directory=str(frontend_dist), html=True), name="frontend")
