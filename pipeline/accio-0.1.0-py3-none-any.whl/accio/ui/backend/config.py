import copy
import os
from pathlib import Path

import yaml
from dotenv import load_dotenv

_projects: dict | None = None
_raw_configs: dict = {}


def _load_from_accio_config() -> dict:
    config_path = os.environ.get("ACCIO_CONFIG")
    if not config_path:
        raise RuntimeError("ACCIO_CONFIG env var not set. Launch via 'accio ui'.")

    config_path = Path(config_path)
    with open(config_path) as f:
        config = yaml.safe_load(f)

    config_dir = config_path.parent
    env_file = config_dir / ".env"
    if env_file.exists():
        load_dotenv(env_file, override=False)

    data = config.get("data", {})

    def resolve(p):
        if not p:
            return None
        path = Path(p)
        return str((config_dir / path).resolve()) if not path.is_absolute() else str(path)

    project_id = config_path.stem
    _raw_configs[project_id] = copy.deepcopy(config)
    name = config.get("name", project_id)
    project_type = config.get("type", "hierarchical")

    # Build schema dict for the UI from the config schema
    schema_cfg = config.get("schema", {})
    props = schema_cfg.get("properties", {})
    eval_cfg = config.get("evaluation", {})
    array_scoring = eval_cfg.get("array_scoring", {})

    ui_schema = {}
    if project_type == "hierarchical":
        sections = []
        fields = {}
        for section_name, section_spec in props.items():
            if section_spec.get("type") == "object":
                sections.append(section_name)
                fields[section_name] = list(section_spec.get("properties", {}).keys())
            elif section_spec.get("type") == "array":
                sections.append(section_name)
                item_props = section_spec.get("items", {}).get("properties", {})
                scoring = array_scoring.get(section_name, {})
                fields[section_name] = scoring.get("fields", list(item_props.keys()))
        ui_schema["sections"] = sections
        ui_schema["fields"] = fields
    else:
        # flat_table
        items = schema_cfg.get("items", {})
        row_id_field = schema_cfg.get("row_id_field", config.get("row_id_field", "id"))
        field_list = list(items.get("properties", {}).keys()) if items else []
        ui_schema["row_id_field"] = row_id_field
        ui_schema["fields"] = field_list

    # Build field_mappings from eval_details short names
    field_mappings = {}
    for arr_name, scoring in array_scoring.items():
        for field in scoring.get("fields", []):
            short = field.replace("_number", "").replace("purchase_", "")
            if short != field:
                field_mappings[short] = field
    # Merge any explicit field_mappings from config
    field_mappings.update(config.get("field_mappings", {}))

    project = {
        "name": name,
        "type": project_type,
        "ground_truth": resolve(data.get("ground_truth")),
        "reference_gt": resolve(data.get("reference_gt")),
        "outputs": resolve(data.get("outputs")),
        "eval_details": resolve(data.get("eval_details")),
        "pdfs": resolve(data.get("pdfs")),
        "schema": ui_schema,
        "field_mappings": field_mappings,
    }

    return {project_id: project}


def load_projects() -> dict:
    global _projects
    if _projects is not None:
        return _projects
    _projects = _load_from_accio_config()
    return _projects


def get_project(project_id: str) -> dict | None:
    projects = load_projects()
    return projects.get(project_id)


def sanitize_config(config: dict) -> dict:
    config = copy.deepcopy(config)
    data = config.get("data", {})
    for key in data:
        data[key] = "(configured)"
    norm = config.get("normalization", {})
    for field_key, field_cfg in norm.items():
        if "catalog_file" in field_cfg:
            field_cfg["catalog_file"] = "(configured)"
        if "lookup" in field_cfg and "file" in field_cfg["lookup"]:
            field_cfg["lookup"]["file"] = "(configured)"
    return config


def get_raw_config(project_id: str) -> dict | None:
    load_projects()
    raw = _raw_configs.get(project_id)
    if not raw:
        return None
    return sanitize_config(raw)


def list_projects() -> list[dict]:
    projects = load_projects()
    return [
        {"id": pid, "name": p["name"], "type": p["type"]}
        for pid, p in projects.items()
    ]
