import json
from pathlib import Path

_cache: dict[str, dict] = {}

def _load_ground_truth(project: dict) -> dict:
    project_id = project.get("name", "unknown")
    if project_id in _cache:
        return _cache[project_id]

    gt_path = Path(project["ground_truth"])

    if project["type"] == "hierarchical":
        if not gt_path.exists():
            return {}
        with open(gt_path) as f:
            data = json.load(f)
        _cache[project_id] = data
        return data
    else:
        if gt_path.is_file():
            with open(gt_path) as f:
                raw = json.load(f)
            doc_id = gt_path.stem
            _cache[project_id] = {doc_id: raw}
            return _cache[project_id]
        elif gt_path.is_dir():
            data = {}
            for p in gt_path.glob("*.json"):
                with open(p) as f:
                    data[p.stem] = json.load(f)
            _cache[project_id] = data
            return data
    return {}

def list_documents(project: dict) -> list[str]:
    return sorted(_load_ground_truth(project).keys())

def get_document(project: dict, doc_id: str) -> dict | None:
    return _load_ground_truth(project).get(doc_id)

def extract_value(field_data) -> str | int | None:
    if field_data is None:
        return None
    if isinstance(field_data, dict):
        return field_data.get("value")
    return field_data

def flatten_document(project: dict, doc_id: str) -> list[dict]:
    doc = get_document(project, doc_id)
    if not doc:
        return []

    if project["type"] == "hierarchical":
        return _flatten_hierarchical(project, doc)
    else:
        return _flatten_flat_table(project, doc)

def _flatten_hierarchical(project: dict, doc: dict) -> list[dict]:
    schema = project.get("schema", {})
    fields_config = schema.get("fields", {})
    result = []

    for section in schema.get("sections", []):
        if section in fields_config:
            section_data = doc.get(section, {})
            if isinstance(section_data, list):
                for i, item in enumerate(section_data):
                    for field in fields_config[section]:
                        result.append({
                            "section": section,
                            "product_index": i,
                            "field": field,
                            "value": extract_value(item.get(field))
                        })
            else:
                for field in fields_config[section]:
                    result.append({
                        "section": section,
                        "field": field,
                        "value": extract_value(section_data.get(field))
                    })

    return result

def _flatten_flat_table(project: dict, doc: dict) -> list[dict]:
    schema = project.get("schema", {})
    fields = schema.get("fields", [])
    row_id_field = schema.get("row_id_field", "id")

    rows = doc.get("rows", doc) if isinstance(doc, dict) else doc
    if not isinstance(rows, list):
        rows = [rows]

    result = []
    for i, row in enumerate(rows):
        row_id = row.get(row_id_field, f"Row {i}")
        for field in fields:
            result.append({
                "section": "row",
                "row_index": i,
                "row_id": row_id,
                "field": field,
                "value": extract_value(row.get(field))
            })

    return result
