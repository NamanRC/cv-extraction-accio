from pathlib import Path
from . import eval_details

def list_models(project: dict) -> list[str]:
    models = set()
    models.update(eval_details.list_models(project))
    if models:
        return sorted(models)

    outputs_dir = Path(project.get("outputs", ""))
    if not outputs_dir.exists():
        return []

    for provider_dir in outputs_dir.iterdir():
        if not provider_dir.is_dir():
            continue
        for model_dir in provider_dir.iterdir():
            if not model_dir.is_dir():
                continue
            if any(model_dir.glob("*.json")):
                models.add(f"{provider_dir.name}/{model_dir.name}")

    return sorted(models)

def aggregate_model(project: dict, model_id: str) -> dict:
    records = eval_details.get_model_records(project, model_id)
    if records:
        total_score = sum(r["score"] for r in records)
        total_possible = sum(r["total"] for r in records)
        total_cost = sum(r.get("cost", 0) for r in records)

        docs = sorted(
            [
                {
                    "doc_id": r["doc_id"],
                    "accuracy": r["accuracy"] / 100.0,
                    "score": r["score"],
                    "total": r["total"],
                    "error_count": r["total"] - r["score"],
                }
                for r in records
            ],
            key=lambda x: x["doc_id"],
        )

        return {
            "model_id": model_id,
            "accuracy": total_score / total_possible if total_possible else 0,
            "cost": total_cost,
            "error_count": total_possible - total_score,
            "document_count": len(records),
            "documents": docs,
        }

    from . import comparison
    docs = comparison.get_model_documents(project, model_id)
    if not docs:
        return {"model_id": model_id, "accuracy": 0, "cost": 0, "error_count": 0, "document_count": 0, "documents": []}

    total_matched = sum(d["matched_fields"] for d in docs)
    total_fields = sum(d["total_fields"] for d in docs)
    total_cost = sum(d.get("metadata", {}).get("cost", 0) or 0 for d in docs)

    return {
        "model_id": model_id,
        "accuracy": total_matched / total_fields if total_fields else 0,
        "cost": total_cost,
        "error_count": total_fields - total_matched,
        "document_count": len(docs),
        "documents": [{"doc_id": d["doc_id"], "accuracy": d["accuracy"], "error_count": len(d["errors"])} for d in docs]
    }

def get_document_score(project: dict, model_id: str, doc_id: str) -> dict | None:
    record = eval_details.get_record(project, model_id, doc_id)
    if not record:
        return None
    return {
        "doc_id": doc_id,
        "accuracy": record["accuracy"] / 100.0,
        "score": record["score"],
        "total": record["total"],
        "error_count": record["total"] - record["score"],
    }
