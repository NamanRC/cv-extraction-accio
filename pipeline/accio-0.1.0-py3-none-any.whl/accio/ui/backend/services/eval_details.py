import json
from pathlib import Path

_cache: dict[str, list[dict]] = {}

def _load(project: dict) -> list[dict]:
    project_name = project.get("name", "unknown")
    if project_name in _cache:
        return _cache[project_name]

    path_str = project.get("eval_details")
    if not path_str:
        return []

    path = Path(path_str)
    if not path.exists():
        return []

    records = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                records.append(json.loads(line))

    _cache[project_name] = records
    return records

def has_data(project: dict) -> bool:
    return len(_load(project)) > 0

def list_models(project: dict) -> list[str]:
    return sorted(set(r["llm"] for r in _load(project)))

def get_model_records(project: dict, model_id: str) -> list[dict]:
    by_doc: dict[str, dict] = {}
    for r in _load(project):
        if r["llm"] == model_id:
            by_doc[r["doc_id"]] = r
    return list(by_doc.values())

def get_record(project: dict, model_id: str, doc_id: str) -> dict | None:
    result = None
    for r in _load(project):
        if r["llm"] == model_id and r["doc_id"] == doc_id:
            result = r
    return result

def clear_cache():
    _cache.clear()
