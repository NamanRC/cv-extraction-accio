import json
import os
from pathlib import Path


def read_explanations() -> dict | None:
    config_path = os.environ.get("ACCIO_CONFIG")
    if not config_path:
        return None
    explain_file = Path(config_path).parent / ".explain.json"
    if not explain_file.exists():
        return None
    with open(explain_file) as f:
        return json.load(f)
