import json
from pathlib import Path
from . import ground_truth, eval_details

_output_cache: dict[str, dict] = {}

# Default short-name mappings for product fields in eval_details
_DEFAULT_FIELD_MAP = {
    "model": "model_number",
    "price": "purchase_price",
    "serial": "serial_number",
    "fd": "fd_number",
}

def _get_field_map(project: dict) -> dict:
    custom = project.get("field_mappings", {})
    if custom:
        merged = dict(_DEFAULT_FIELD_MAP)
        merged.update(custom)
        return merged
    return _DEFAULT_FIELD_MAP

def _extract_value(val):
    if isinstance(val, dict) and "value" in val:
        return val["value"]
    return val

def _normalize(val) -> str:
    val = _extract_value(val)
    if val is None:
        return ""
    s = str(val).strip()
    s = s.replace('\u2013', '-').replace('\u2014', '-').replace('\u00a3', '\u00a3')
    return s

def _classify_error(expected, extracted) -> str:
    exp_norm = _normalize(expected)
    ext_norm = _normalize(extracted)

    if not ext_norm and exp_norm:
        return "missing"
    if exp_norm.lower() == ext_norm.lower() and exp_norm != ext_norm:
        return "case"
    exp_alphanum = ''.join(c.lower() for c in exp_norm if c.isalnum())
    ext_alphanum = ''.join(c.lower() for c in ext_norm if c.isalnum())
    if exp_alphanum == ext_alphanum and exp_norm != ext_norm:
        return "format"
    return "wrong_value"

def _convert_eval_record(record: dict, field_map: dict | None = None) -> dict:
    field_map = field_map or _DEFAULT_FIELD_MAP
    doc_id = record["doc_id"]
    fields = record.get("fields", {})
    products = record.get("products", [])

    errors = []
    all_fields = []
    total_fields = 0
    matched_fields = 0
    field_totals: dict[str, int] = {}

    for field_key, info in fields.items():
        parts = field_key.split(".", 1)
        section = parts[0] if len(parts) == 2 else ""
        field = parts[1] if len(parts) == 2 else parts[0]
        key = f"{section}.{field}" if section else field

        field_detail = {
            "section": section,
            "field": field,
            "match": bool(info.get("match")),
            "skip": bool(info.get("skip")),
            "extracted": info.get("extracted"),
            "expected": info.get("expected"),
            "normalization": info.get("normalization"),
        }
        all_fields.append(field_detail)

        if info.get("skip"):
            continue
        total_fields += 1
        field_totals[key] = field_totals.get(key, 0) + 1

        if info.get("match"):
            matched_fields += 1
            continue

        errors.append({
            "section": section,
            "field": field,
            "expected": info.get("expected"),
            "extracted": info.get("extracted"),
            "match": False,
            "error_type": _classify_error(info.get("expected"), info.get("extracted")),
        })

    pool_matched_fields = 0
    has_pool = False

    # Process all array sections (products, education, experience, etc.)
    _non_section_keys = {
        "doc_id", "llm", "accuracy", "score", "total", "cost",
        "timestamp", "fields", "pool_score", "pool_total", "pool_accuracy",
    }
    array_sections = [
        (k, v) for k, v in record.items()
        if isinstance(v, list) and k not in _non_section_keys
    ]

    for section_name, items in array_sections:
        for i, item in enumerate(items):
            for short_name, info in item.items():
                schema_name = field_map.get(short_name, short_name)
                key = f"{section_name}.{schema_name}"

                field_detail = {
                    "section": section_name,
                    "product_index": i,
                    "field": schema_name,
                    "match": bool(info.get("match")),
                    "skip": bool(info.get("skip")),
                    "extracted": info.get("extracted"),
                    "expected": info.get("expected"),
                    "normalization": info.get("normalization"),
                }
                if "pool_match" in info:
                    field_detail["pool_match"] = bool(info["pool_match"])
                    has_pool = True
                all_fields.append(field_detail)

                if info.get("skip"):
                    continue
                total_fields += 1
                field_totals[key] = field_totals.get(key, 0) + 1

                if "pool_match" in info and info["pool_match"]:
                    pool_matched_fields += 1

                if info.get("match"):
                    matched_fields += 1
                    continue

                expected = info.get("expected")
                extracted = info.get("extracted")
                if expected is None and extracted is not None:
                    error_type = "wrong_value"
                else:
                    error_type = _classify_error(expected, extracted)

                errors.append({
                    "section": section_name,
                    "product_index": i,
                    "field": schema_name,
                    "expected": expected,
                    "extracted": extracted,
                    "match": False,
                    "error_type": error_type,
                })

    accuracy = record.get("accuracy", 0) / 100.0

    result = {
        "doc_id": doc_id,
        "accuracy": accuracy,
        "total_fields": total_fields,
        "matched_fields": matched_fields,
        "errors": errors,
        "all_fields": all_fields,
        "metadata": {"cost": record.get("cost", 0)},
        "field_totals": field_totals,
    }

    if has_pool:
        result["pool_accuracy"] = record.get("pool_accuracy", 0) / 100.0 if record.get("pool_accuracy") else None
        result["pool_score"] = record.get("pool_score")
        result["pool_total"] = record.get("pool_total")

    return result

def _load_output(project: dict, model_id: str, doc_id: str) -> dict | None:
    cache_key = f"{project.get('name')}:{model_id}:{doc_id}"
    if cache_key in _output_cache:
        return _output_cache[cache_key]

    outputs_dir = Path(project.get("outputs", ""))
    if not outputs_dir.exists():
        return None

    parts = model_id.split("/", 1)
    if len(parts) != 2:
        return None

    provider, model = parts
    output_file = outputs_dir / provider / model / f"{doc_id}.json"

    if not output_file.exists():
        return None

    with open(output_file) as f:
        data = json.load(f)

    _output_cache[cache_key] = data
    return data

def compare_document(project: dict, model_id: str, doc_id: str) -> dict:
    record = eval_details.get_record(project, model_id, doc_id)
    if record:
        return _convert_eval_record(record, _get_field_map(project))

    gt_doc = ground_truth.get_document(project, doc_id)
    output = _load_output(project, model_id, doc_id)

    if not gt_doc:
        return {
            "doc_id": doc_id,
            "accuracy": 0,
            "total_fields": 0,
            "matched_fields": 0,
            "errors": [],
            "metadata": {},
            "error": "No ground truth found"
        }

    if not output:
        return {
            "doc_id": doc_id,
            "accuracy": 0,
            "total_fields": 0,
            "matched_fields": 0,
            "errors": [],
            "metadata": {},
            "error": "No extraction output found"
        }

    project_type = project.get("type", "hierarchical")
    schema = project.get("schema", {})

    if project_type == "flat_table":
        result = _compare_flat_table(doc_id, gt_doc, output, schema)
    else:
        result = _compare_hierarchical(doc_id, gt_doc, output, schema)

    return result

def _compare_flat_table(doc_id: str, gt_doc: dict, output: dict, schema: dict) -> dict:
    fields = schema.get("fields", [])
    row_id_field = schema.get("row_id_field", "id")

    if isinstance(output, dict) and "data" in output:
        output = output["data"]

    gt_rows = gt_doc.get("rows", [])
    if isinstance(output, list):
        out_rows = output
    else:
        out_rows = output.get("rows", [])

    out_by_id = {}
    for i, row in enumerate(out_rows):
        rid = row.get(row_id_field, f"Row {i}")
        out_by_id[rid] = row

    errors = []
    total_fields = 0
    matched_fields = 0

    for i, gt_row in enumerate(gt_rows):
        row_id = gt_row.get(row_id_field, f"Row {i}")
        out_row = out_by_id.get(row_id, {})

        for field in fields:
            expected = _extract_value(gt_row.get(field))
            if expected is None:
                continue
            total_fields += 1
            extracted = _extract_value(out_row.get(field))

            exp_norm = _normalize(expected)
            ext_norm = _normalize(extracted)

            if exp_norm == ext_norm:
                matched_fields += 1
            else:
                errors.append({
                    "section": "row",
                    "row_index": i,
                    "row_id": row_id,
                    "field": field,
                    "expected": expected,
                    "extracted": extracted,
                    "match": False,
                    "error_type": _classify_error(expected, extracted)
                })

    accuracy = matched_fields / total_fields if total_fields > 0 else 1.0

    return {
        "doc_id": doc_id,
        "accuracy": accuracy,
        "total_fields": total_fields,
        "matched_fields": matched_fields,
        "errors": errors,
        "metadata": output.get("metadata", {}) if isinstance(output, dict) else {}
    }

def _compare_hierarchical(doc_id: str, gt_doc: dict, output: dict, schema: dict) -> dict:
    sections = schema.get("sections", [])
    fields_config = schema.get("fields", {})

    if "data" in output:
        output = output["data"]

    errors = []
    total_fields = 0
    matched_fields = 0

    for section in sections:
        section_fields = fields_config.get(section, [])
        gt_section = gt_doc.get(section, {})
        out_section = output.get(section, {})

        if isinstance(gt_section, list):
            for i, gt_item in enumerate(gt_section):
                out_item = out_section[i] if isinstance(out_section, list) and i < len(out_section) else {}

                for field in section_fields:
                    expected = _extract_value(gt_item.get(field))
                    if expected is None:
                        continue
                    total_fields += 1
                    extracted = _extract_value(out_item.get(field))

                    exp_norm = _normalize(expected)
                    ext_norm = _normalize(extracted)

                    if exp_norm == ext_norm:
                        matched_fields += 1
                    else:
                        errors.append({
                            "section": section,
                            "product_index": i,
                            "field": field,
                            "expected": expected,
                            "extracted": extracted,
                            "match": False,
                            "error_type": _classify_error(expected, extracted)
                        })
        else:
            for field in section_fields:
                expected = _extract_value(gt_section.get(field))
                if expected is None:
                    continue
                total_fields += 1
                extracted = _extract_value(out_section.get(field))

                exp_norm = _normalize(expected)
                ext_norm = _normalize(extracted)

                if exp_norm == ext_norm:
                    matched_fields += 1
                else:
                    errors.append({
                        "section": section,
                        "field": field,
                        "expected": expected,
                        "extracted": extracted,
                        "match": False,
                        "error_type": _classify_error(expected, extracted)
                    })

    accuracy = matched_fields / total_fields if total_fields > 0 else 1.0

    return {
        "doc_id": doc_id,
        "accuracy": accuracy,
        "total_fields": total_fields,
        "matched_fields": matched_fields,
        "errors": errors,
        "metadata": output.get("metadata", {})
    }

def get_model_documents(project: dict, model_id: str) -> list[dict]:
    records = eval_details.get_model_records(project, model_id)
    if records:
        field_map = _get_field_map(project)
        return sorted(
            [_convert_eval_record(r, field_map) for r in records],
            key=lambda x: x["doc_id"],
        )

    doc_ids = ground_truth.list_documents(project)
    results = []

    for doc_id in doc_ids:
        result = compare_document(project, model_id, doc_id)
        results.append(result)

    return sorted(results, key=lambda x: x["doc_id"])

def clear_cache():
    _output_cache.clear()
    eval_details.clear_cache()
