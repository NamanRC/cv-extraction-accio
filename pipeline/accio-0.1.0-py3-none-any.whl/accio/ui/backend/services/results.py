import json
from pathlib import Path

def list_models(project: dict) -> list[str]:
    outputs_dir = Path(project["outputs"])
    if not outputs_dir.exists():
        return []
    models = []
    for provider_dir in outputs_dir.iterdir():
        if not provider_dir.is_dir():
            continue
        for model_dir in provider_dir.iterdir():
            if model_dir.is_dir():
                models.append(f"{provider_dir.name}/{model_dir.name}")
    return sorted(models)

def load_result(project: dict, model_id: str, doc_id: str) -> dict | None:
    parts = model_id.split("/", 1)
    if len(parts) != 2:
        return None
    provider, model = parts
    outputs_dir = Path(project["outputs"])
    path = outputs_dir / provider / model / f"{doc_id}.json"
    if not path.exists():
        return None
    with open(path) as f:
        raw = json.load(f)
    if isinstance(raw, list):
        return {"rows": raw, "metadata": {}}
    return raw

def list_results_for_model(project: dict, model_id: str) -> list[str]:
    parts = model_id.split("/", 1)
    if len(parts) != 2:
        return []
    provider, model = parts
    outputs_dir = Path(project["outputs"])
    model_dir = outputs_dir / provider / model
    if not model_dir.exists():
        return []
    return sorted(p.stem for p in model_dir.glob("*.json"))

def extract_value(field_data) -> str | int | None:
    if field_data is None:
        return None
    if isinstance(field_data, dict):
        return field_data.get("value")
    return field_data

def flatten_extraction(project: dict, result: dict) -> list[dict]:
    if not result or result.get("error"):
        return []

    data = result.get("data", result)

    if project["type"] == "hierarchical":
        return _flatten_hierarchical(project, data)
    else:
        return _flatten_flat_table(project, data)

def _flatten_hierarchical(project: dict, result: dict) -> list[dict]:
    schema = project.get("schema", {})
    fields_config = schema.get("fields", {})
    fields = []

    for section in schema.get("sections", []):
        section_data = result.get(section, {})
        section_fields = fields_config.get(section, [])

        if isinstance(section_data, list):
            for i, item in enumerate(section_data):
                for field in section_fields:
                    fields.append({
                        "section": section,
                        "product_index": i,
                        "field": field,
                        "value": extract_value(item.get(field))
                    })
        else:
            for field in section_fields:
                fields.append({
                    "section": section,
                    "field": field,
                    "value": extract_value(section_data.get(field))
                })

    return fields

def _flatten_flat_table(project: dict, result: dict) -> list[dict]:
    schema = project.get("schema", {})
    fields = schema.get("fields", [])
    row_id_field = schema.get("row_id_field", "id")

    rows = result.get("rows", result) if isinstance(result, dict) else result
    if not isinstance(rows, list):
        rows = [rows]

    output = []
    for i, row in enumerate(rows):
        row_id = row.get(row_id_field, f"Row {i}")
        for field in fields:
            output.append({
                "section": "row",
                "row_index": i,
                "row_id": row_id,
                "field": field,
                "value": extract_value(row.get(field))
            })

    return output

def get_metadata(result: dict) -> dict:
    if not isinstance(result, dict):
        return {}
    if "metadata" in result:
        return result["metadata"]
    if "cost" in result:
        return {"cost": result.get("cost"), "input_tokens": result.get("input_tokens"), "output_tokens": result.get("output_tokens")}
    return {}
