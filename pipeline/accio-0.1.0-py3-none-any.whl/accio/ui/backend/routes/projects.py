from fastapi import APIRouter
from accio.ui.backend.config import list_projects, get_project, get_raw_config
from accio.ui.backend.services.explain import read_explanations

router = APIRouter(prefix="/api/projects", tags=["projects"])

@router.get("")
def get_projects():
    return list_projects()

@router.get("/{project_id}")
def get_project_info(project_id: str):
    project = get_project(project_id)
    if not project:
        return {"error": "Project not found"}
    return {
        "id": project_id,
        "name": project["name"],
        "type": project["type"]
    }

@router.get("/{project_id}/config")
def get_project_config(project_id: str):
    raw = get_raw_config(project_id)
    if not raw:
        return {"error": "Project not found"}
    return raw

@router.get("/{project_id}/config/explain")
def get_config_explanations(project_id: str):
    data = read_explanations()
    if not data:
        return {"available": False}
    return {**data, "available": True}
