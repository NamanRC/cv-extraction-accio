from pathlib import Path
from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
from accio.ui.backend.config import get_project

router = APIRouter(prefix="/api/projects/{project_id}", tags=["pdfs"])

def _get_project(project_id: str) -> dict:
    project = get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail=f"Project '{project_id}' not found")
    return project

def find_pdf(pdfs_dir: Path, doc_id: str):
    for ext in ["*.pdf", "*.PDF"]:
        for path in pdfs_dir.glob(f"{doc_id}*{ext[1:]}"):
            return path
    exact = pdfs_dir / f"{doc_id}.pdf"
    if exact.exists():
        return exact
    exact = pdfs_dir / f"{doc_id}.PDF"
    if exact.exists():
        return exact
    return None

@router.get("/pdfs/{doc_id}")
def get_pdf(project_id: str, doc_id: str):
    project = _get_project(project_id)
    pdfs_dir = Path(project["pdfs"])
    path = find_pdf(pdfs_dir, doc_id)
    if not path:
        raise HTTPException(status_code=404, detail="PDF not found")
    return FileResponse(
        path,
        media_type="application/pdf",
        filename=f"{doc_id}.pdf",
        headers={"Content-Disposition": f"inline; filename=\"{doc_id}.pdf\""},
    )
