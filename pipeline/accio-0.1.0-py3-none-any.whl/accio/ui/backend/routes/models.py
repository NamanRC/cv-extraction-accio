from fastapi import APIRouter, HTTPException
from accio.ui.backend.config import get_project
from accio.ui.backend.services import scores, comparison

router = APIRouter(prefix="/api/projects/{project_id}", tags=["models"])

def _get_project(project_id: str) -> dict:
    project = get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail=f"Project '{project_id}' not found")
    return project

@router.get("/models")
def list_models(project_id: str):
    project = _get_project(project_id)
    models = scores.list_models(project)
    return [scores.aggregate_model(project, m) for m in models]

@router.get("/models/{provider}/{model}")
def get_model(project_id: str, provider: str, model: str):
    project = _get_project(project_id)
    model_id = f"{provider}/{model}"
    return scores.aggregate_model(project, model_id)

@router.get("/models/{provider}/{model}/documents")
def get_model_documents(project_id: str, provider: str, model: str):
    project = _get_project(project_id)
    model_id = f"{provider}/{model}"
    return comparison.get_model_documents(project, model_id)
