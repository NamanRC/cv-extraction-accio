from fastapi import APIRouter, HTTPException
from accio.ui.backend.config import get_project
from accio.ui.backend.services import ground_truth, scores

router = APIRouter(prefix="/api/projects/{project_id}", tags=["documents"])

def _get_project(project_id: str) -> dict:
    project = get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail=f"Project '{project_id}' not found")
    return project

@router.get("/documents")
def list_documents(project_id: str):
    project = _get_project(project_id)
    return ground_truth.list_documents(project)

@router.get("/documents/{doc_id}")
def get_document(project_id: str, doc_id: str):
    project = _get_project(project_id)
    doc = ground_truth.get_document(project, doc_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    return {
        "doc_id": doc_id,
        "ground_truth": ground_truth.flatten_document(project, doc_id)
    }

@router.get("/documents/{doc_id}/score/{provider}/{model}")
def get_document_score(project_id: str, doc_id: str, provider: str, model: str):
    project = _get_project(project_id)
    model_id = f"{provider}/{model}"
    score = scores.get_document_score(project, model_id, doc_id)
    if not score:
        raise HTTPException(status_code=404, detail="No score for this model/document")
    return score
