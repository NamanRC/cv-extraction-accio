"""accio — PDF table extraction, evaluation, and benchmarking."""

from pathlib import Path


def load_config(config_path):
    from accio.core import load_config as _load_config
    return _load_config(config_path)


def available_llms():
    from accio.core import available_llms as _available_llms
    return _available_llms()


def run(config, llm=None, pdf=None, parallel=False, no_cache=False,
        consensus=False, output=None, ground_truth=None):
    """Batch extraction + evaluation. Returns structured results dict.

    Args:
        config: Path to config YAML (str/Path) or pre-loaded config dict.
        llm: LLM name (str) or list of names. None = all available.
        pdf: Path to a single PDF, or None for all PDFs in config's data.pdfs.
        parallel: Run extractions in parallel.
        no_cache: Skip cache, force new extraction.
        consensus: Build multi-extractor consensus.
        output: Output directory for raw extraction JSON.
        ground_truth: Path to ground truth JSON file.

    Returns:
        Dict with keys: results, session_cost, eval_schema, unavailable_llms.

    Raises:
        ValueError: If PDF not found or no PDFs directory configured.
        RuntimeError: If no LLMs available.
    """
    from accio.core import (
        _load_ground_truth,
        _resolve_pdfs,
        available_llms as _available_llms,
        parse_eval_schema,
        run_batch,
    )

    if isinstance(config, (str, Path)):
        config = load_config(config)

    eval_schema = parse_eval_schema(config)

    if llm is None:
        llms = _available_llms()
    elif isinstance(llm, str):
        llms = [llm]
    else:
        llms = list(llm)

    if not llms:
        raise RuntimeError("No LLMs available. Set API keys: GOOGLE_API_KEY, OPENAI_API_KEY, ANTHROPIC_API_KEY")

    pdfs = _resolve_pdfs(pdf, config)
    gt_data = _load_ground_truth(ground_truth, config)

    if not output and config:
        output = config.get("data", {}).get("outputs")

    return run_batch(
        config=config, pdfs=pdfs, llms=llms, eval_schema=eval_schema,
        gt_data=gt_data, no_cache=no_cache, output=output,
        consensus=consensus, parallel=parallel,
    )


def extract(pdf, config, llm, no_cache=False, normalize=True, verify=True):
    """Extract data from a single PDF with a single LLM.

    Args:
        pdf: Path to PDF file.
        config: Path to config YAML (str/Path) or pre-loaded config dict.
        llm: LLM name (e.g. "gemini/gemini-2.5-flash").
        no_cache: Skip cache, force new extraction.
        normalize: Apply normalization rules from config.
        verify: Run LLM verification on fields with verify config.

    Returns:
        Dict with keys: data, cost, norm_traces, raw_result.
    """
    from accio.core import (
        extract as _extract,
        get_cached,
        normalize_traced,
        set_cache,
        verify_fields,
    )

    if isinstance(config, (str, Path)):
        config = load_config(config)

    pdf_path = Path(pdf)
    if not pdf_path.exists():
        raise ValueError(f"PDF not found: {pdf}")

    cached, is_fallback = get_cached(str(pdf_path), llm, config)
    if cached and not no_cache:
        result = cached
        extraction_cost = 0
    else:
        result = _extract(str(pdf_path), config, llm)
        set_cache(str(pdf_path), llm, config, result)
        extraction_cost = result["cost"]

    data = result["data"]
    norm_traces = {}
    verify_cost = 0

    if normalize and config and config.get("normalization"):
        data, norm_traces = normalize_traced(data, config)

    if verify:
        verify_cost = verify_fields(data, config, str(pdf_path), llm, norm_traces)

    return {
        "data": data,
        "cost": extraction_cost + verify_cost,
        "norm_traces": norm_traces,
        "raw_result": result,
    }
