import os


PROMPT = """Below is a YAML config for a document data extraction pipeline.
For each step, write 1-2 plain sentences explaining what happens. Be direct and specific to this config — say what fields, what rules, what matching logic. No filler, no jargon.

Return a JSON object with these keys:
- "overview": What does this pipeline do, end to end?
- "schema": What fields get extracted? How are they grouped?
- "system_prompt": What is the LLM told to do? Any special instructions?
- "normalization": What cleanup or matching happens to extracted values?
- "verification": Which fields does the LLM re-check after normalization, and why?
- "evaluation": How are extracted results compared to ground truth?

Set a key to null if that section isn't in the config.
Return ONLY valid JSON, no markdown fencing.

---
CONFIG:
{config_yaml}
"""


def pick_llm() -> tuple[str, str] | None:
    if os.environ.get("GOOGLE_API_KEY") or os.environ.get("GEMINI_API_KEY"):
        return ("gemini", "gemini-2.5-flash")
    if os.environ.get("OPENAI_API_KEY"):
        return ("openai", "gpt-4.1-mini")
    if os.environ.get("ANTHROPIC_API_KEY"):
        return ("anthropic", "claude-sonnet-4-20250514")
    return None


def generate_text(prompt: str, provider: str, model: str) -> str:
    if provider == "gemini":
        from google import genai
        client = genai.Client()
        response = client.models.generate_content(model=model, contents=prompt)
        return response.text

    if provider == "openai":
        from openai import OpenAI
        client = OpenAI()
        response = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.choices[0].message.content

    if provider == "anthropic":
        import anthropic
        client = anthropic.Anthropic()
        response = client.messages.create(
            model=model,
            max_tokens=4000,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.content[0].text

    raise ValueError(f"Unknown provider: {provider}")
