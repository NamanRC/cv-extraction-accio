"""PDF table extraction and evaluation engine."""

import base64
import hashlib
import json
import os
import re
import sys
import threading
from collections import Counter
from datetime import datetime
from difflib import SequenceMatcher
from pathlib import Path

import yaml
from dotenv import load_dotenv
from rich.console import Console
from rich.markup import escape
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

console = Console()

load_dotenv(dotenv_path=Path.cwd() / ".env", override=False)  # cwd .env

PRICING = {
    "gemini/gemini-2.5-pro": (1.25, 10.0),
    "gemini/gemini-2.5-flash": (0.15, 0.60),
    "gemini/gemini-3-pro-preview": (2.0, 12.0),
    "gemini/gemini-3-flash-preview": (0.50, 3.0),
    "openai/gpt-5": (1.25, 10.0),
    "openai/gpt-5-mini": (0.25, 2.0),
    "openai/gpt-5-nano": (0.05, 0.4),
    "anthropic/claude-sonnet-4-20250514": (3.0, 15.0),
    "anthropic/claude-opus-4-5-20251101": (15.0, 75.0),
}


def cost(llm, input_tokens, output_tokens):
    p = PRICING.get(llm, (0, 0))
    return (input_tokens * p[0] + output_tokens * p[1]) / 1_000_000


def load_config(config_path):
    config_path = Path(config_path).resolve()
    with open(config_path) as f:
        config = yaml.safe_load(f)

    config_dir = config_path.parent
    # Load .env from config dir if present
    env_file = config_dir / ".env"
    if env_file.exists():
        load_dotenv(env_file, override=False)

    data = config.get("data", {})
    for key in ("pdfs", "ground_truth", "outputs", "eval_details"):
        if key in data and data[key]:
            p = Path(data[key])
            if not p.is_absolute():
                data[key] = str((config_dir / p).resolve())
    config["data"] = data
    config["_config_dir"] = str(config_dir.resolve())
    return config


# --- Caching ---

def _cache_dir(config):
    config_dir = Path(config.get("_config_dir", "."))
    return config_dir / ".cache"


def extraction_config(config):
    if not config:
        return {}
    return {k: v for k, v in config.items() if k in ("system_prompt", "schema")}


def schema_hash(config):
    schema = config.get("schema") if config else None
    return hashlib.md5(json.dumps(schema, sort_keys=True).encode()).hexdigest()[:8] if schema else "none"


_pdf_hash_cache = {}
_pdf_hash_lock = threading.Lock()


def _get_pdf_hash(pdf_path):
    pdf_path = str(pdf_path)
    if pdf_path not in _pdf_hash_cache:
        with _pdf_hash_lock:
            if pdf_path not in _pdf_hash_cache:
                with open(pdf_path, "rb") as f:
                    _pdf_hash_cache[pdf_path] = hashlib.md5(f.read()).hexdigest()[:12]
    return _pdf_hash_cache[pdf_path]


def cache_key(pdf_path, llm, config):
    pdf_hash = _get_pdf_hash(pdf_path)
    ext_config = extraction_config(config)
    config_hash = hashlib.md5(json.dumps(ext_config, sort_keys=True).encode()).hexdigest()[:8]
    return f"{pdf_hash}_{llm.replace('/', '_')}_{config_hash}"


def get_cached(pdf_path, llm, config):
    cdir = _cache_dir(config)
    key = cache_key(pdf_path, llm, config)
    cache_file = cdir / f"{key}.json"
    if cache_file.exists():
        with open(cache_file) as f:
            return json.load(f), False

    pdf_hash = _get_pdf_hash(pdf_path)
    llm_part = llm.replace('/', '_')

    for cache_file in cdir.glob(f"{pdf_hash}_{llm_part}_*.json"):
        with open(cache_file) as f:
            cached = json.load(f)
        cached_data = cached.get("data", {})
        if isinstance(cached_data, dict):
            return cached, True
    return None, False


def set_cache(pdf_path, llm, config, result):
    cdir = _cache_dir(config)
    cdir.mkdir(exist_ok=True)
    key = cache_key(pdf_path, llm, config)
    cache_file = cdir / f"{key}.json"
    with open(cache_file, "w") as f:
        json.dump(result, f, indent=2)


# --- Date normalization ---

def parse_date(val):
    if not val:
        return None
    s = str(val).strip()
    for fmt in ["%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y", "%m-%d-%Y", "%m-%d-%y", "%d/%m/%Y", "%d/%m/%y", "%Y/%m/%d"]:
        try:
            return datetime.strptime(s.split()[0], fmt).date()
        except Exception:
            pass
    for fmt in ["%B %d, %Y", "%b %d, %Y", "%B %d %Y", "%b %d %Y"]:
        try:
            return datetime.strptime(s, fmt).date()
        except Exception:
            pass
    return None


def dates_equal(a, b):
    da, db = parse_date(a), parse_date(b)
    if da and db:
        return da == db
    return False


def available_llms():
    avail = []
    if os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY"):
        avail.extend([k for k in PRICING if k.startswith("gemini/")])
    if os.getenv("OPENAI_API_KEY"):
        avail.extend([k for k in PRICING if k.startswith("openai/")])
    if os.getenv("ANTHROPIC_API_KEY"):
        avail.extend([k for k in PRICING if k.startswith("anthropic/")])
    return avail


def build_prompt(config):
    if not config:
        return "Extract all tables from this PDF as JSON."
    parts = []
    if config.get("system_prompt"):
        parts.append(config["system_prompt"])
    if config.get("schema"):
        parts.append("Extract data matching this schema:")
        parts.append(json.dumps(config["schema"], indent=2))
    parts.append("Rules:\n- Return JSON\n- Use null for missing fields")
    return "\n\n".join(parts)


def extract_gemini(pdf_path, config, model):
    from google import genai
    from google.genai import types

    with open(pdf_path, "rb") as f:
        pdf_bytes = f.read()

    client = genai.Client(api_key=os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY"))
    resp = client.models.generate_content(
        model=model,
        contents=[types.Part.from_bytes(data=pdf_bytes, mime_type="application/pdf"), build_prompt(config)],
        config=types.GenerateContentConfig(response_mime_type="application/json", temperature=0)
    )

    text = next(p.text for p in resp.candidates[0].content.parts if p.text is not None)
    data = json.loads(text)
    inp = getattr(resp.usage_metadata, 'prompt_token_count', 0)
    out = getattr(resp.usage_metadata, 'candidates_token_count', 0)
    return {"data": data, "input_tokens": inp, "output_tokens": out, "cost": cost(f"gemini/{model}", inp, out)}


def extract_openai(pdf_path, config, model):
    from openai import OpenAI

    with open(pdf_path, "rb") as f:
        pdf_b64 = base64.b64encode(f.read()).decode()

    resp = OpenAI().responses.create(
        model=model,
        input=[{
            "role": "user",
            "content": [
                {"type": "input_file", "filename": "document.pdf", "file_data": f"data:application/pdf;base64,{pdf_b64}"},
                {"type": "input_text", "text": build_prompt(config)}
            ]
        }],
        text={"format": {"type": "json_object"}}
    )

    data = json.loads(resp.output_text)
    return {"data": data, "input_tokens": resp.usage.input_tokens, "output_tokens": resp.usage.output_tokens,
            "cost": cost(f"openai/{model}", resp.usage.input_tokens, resp.usage.output_tokens)}


def extract_anthropic(pdf_path, config, model):
    from anthropic import Anthropic

    with open(pdf_path, "rb") as f:
        pdf_b64 = base64.b64encode(f.read()).decode()

    tool = {
        "name": "extract_data",
        "description": "Extract structured data from document",
        "input_schema": config["schema"] if config and config.get("schema") else {"type": "object", "properties": {}}
    }

    resp = Anthropic().messages.create(
        model=model,
        max_tokens=16000,
        temperature=0,
        tools=[tool],
        tool_choice={"type": "tool", "name": tool["name"]},
        messages=[{
            "role": "user",
            "content": [
                {"type": "document", "source": {"type": "base64", "media_type": "application/pdf", "data": pdf_b64}},
                {"type": "text", "text": build_prompt(config)}
            ]
        }]
    )

    data = resp.content[0].input
    return {"data": data, "input_tokens": resp.usage.input_tokens, "output_tokens": resp.usage.output_tokens,
            "cost": cost(f"anthropic/{model}", resp.usage.input_tokens, resp.usage.output_tokens)}


def extract(pdf_path, config, llm):
    provider, model = llm.split("/", 1)
    if provider == "gemini":
        return extract_gemini(pdf_path, config, model)
    elif provider == "openai":
        return extract_openai(pdf_path, config, model)
    elif provider == "anthropic":
        return extract_anthropic(pdf_path, config, model)
    raise ValueError(f"Unknown provider: {provider}")


def verify_with_llm(pdf_path, llm, prompt):
    provider, model = llm.split("/", 1)
    with open(pdf_path, "rb") as f:
        pdf_bytes = f.read()

    if provider == "gemini":
        from google import genai
        from google.genai import types
        client = genai.Client(api_key=os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY"))
        resp = client.models.generate_content(
            model=model,
            contents=[types.Part.from_bytes(data=pdf_bytes, mime_type="application/pdf"), prompt],
            config=types.GenerateContentConfig(temperature=0)
        )
        inp = getattr(resp.usage_metadata, 'prompt_token_count', 0)
        out = getattr(resp.usage_metadata, 'candidates_token_count', 0)
        return resp.text.strip(), cost(f"gemini/{model}", inp, out)
    elif provider == "openai":
        from openai import OpenAI
        pdf_b64 = base64.b64encode(pdf_bytes).decode()
        resp = OpenAI().responses.create(
            model=model,
            input=[{"role": "user", "content": [
                {"type": "input_file", "filename": "document.pdf", "file_data": f"data:application/pdf;base64,{pdf_b64}"},
                {"type": "input_text", "text": prompt}
            ]}]
        )
        return resp.output_text.strip(), cost(f"openai/{model}", resp.usage.input_tokens, resp.usage.output_tokens)
    elif provider == "anthropic":
        from anthropic import Anthropic
        pdf_b64 = base64.b64encode(pdf_bytes).decode()
        resp = Anthropic().messages.create(
            model=model, max_tokens=1024, temperature=0,
            messages=[{"role": "user", "content": [
                {"type": "document", "source": {"type": "base64", "media_type": "application/pdf", "data": pdf_b64}},
                {"type": "text", "text": prompt}
            ]}]
        )
        text = resp.content[0].text if resp.content else ""
        return text.strip(), cost(f"anthropic/{model}", resp.usage.input_tokens, resp.usage.output_tokens)
    raise ValueError(f"Unknown provider: {provider}")


# --- Normalization ---

def apply_rules(value, rules):
    if not value or not rules:
        return value
    result = value
    for rule in rules:
        if rule.startswith("strip:"):
            result = re.sub(rule[6:], '', result)
        elif rule.startswith("replace:"):
            parts = rule.split(":", 2)
            if len(parts) == 3:
                result = re.sub(parts[1], parts[2], result)
    return result


def fuzzy_match(value, catalog, threshold=0.8):
    if not value or not catalog:
        return None
    best, best_score = None, 0
    val_up = value.upper()
    for item in catalog:
        item_up = item.upper()
        if val_up == item_up:
            return item
        if item_up in val_up or val_up in item_up:
            score = len(item) / max(len(value), len(item))
        else:
            score = SequenceMatcher(None, val_up, item_up).ratio()
        if score > best_score:
            best_score, best = score, item
    return best if best_score >= threshold else None


_catalog_cache = {}
_catalog_lock = threading.Lock()


def load_catalog(field_config, config_dir=None):
    if field_config.get("catalog"):
        return field_config["catalog"]
    if field_config.get("catalog_file"):
        path = field_config["catalog_file"]
        if config_dir and not Path(path).is_absolute():
            path = str(Path(config_dir) / path)
        if path not in _catalog_cache:
            with _catalog_lock:
                if path not in _catalog_cache:
                    with open(path) as f:
                        data = json.load(f)
                        _catalog_cache[path] = list(data.keys()) if isinstance(data, dict) else data
        return _catalog_cache[path]
    return None


_lookup_cache = {}
_lookup_lock = threading.Lock()


def load_lookup(lookup_config, config_dir=None):
    if not lookup_config or not lookup_config.get("file"):
        return None
    path = lookup_config["file"]
    if config_dir and not Path(path).is_absolute():
        path = str(Path(config_dir) / path)
    if path not in _lookup_cache:
        with _lookup_lock:
            if path not in _lookup_cache:
                with open(path) as f:
                    _lookup_cache[path] = json.load(f)
    return _lookup_cache[path]


def normalize_field(value, field_config, config_dir=None, context=None):
    if not value or not field_config:
        return value
    result = str(value)
    if field_config.get("rules"):
        result = apply_rules(result, field_config["rules"])
    catalog = load_catalog(field_config, config_dir)
    if catalog:
        matched = fuzzy_match(result, catalog, field_config.get("threshold", 0.8))
        if matched:
            result = matched
    lookup_config = field_config.get("lookup")
    if lookup_config and context:
        table = load_lookup(lookup_config, config_dir)
        if table:
            key_val = context.get(lookup_config.get("key_field"))
            if key_val:
                entry = table.get(key_val, {})
                candidates = entry.get(lookup_config.get("value_field"), [])
                matched = fuzzy_match(result, candidates, lookup_config.get("threshold", 0.8))
                if matched:
                    result = matched
    return result


def normalize_field_traced(value, field_config, config_dir=None, context=None):
    if not value or not field_config:
        return value, None
    raw = str(value)
    result = raw
    steps = []
    if field_config.get("rules"):
        after_rules = apply_rules(result, field_config["rules"])
        if after_rules != result:
            steps.append({"type": "rules", "result": after_rules})
        result = after_rules
    catalog = load_catalog(field_config, config_dir)
    if catalog:
        matched = fuzzy_match(result, catalog, field_config.get("threshold", 0.8))
        if matched and matched != result:
            steps.append({"type": "catalog_match", "result": matched})
            result = matched
    lookup_config = field_config.get("lookup")
    if lookup_config and context:
        table = load_lookup(lookup_config, config_dir)
        if table:
            key_val = context.get(lookup_config.get("key_field"))
            if key_val:
                entry = table.get(key_val, {})
                candidates = entry.get(lookup_config.get("value_field"), [])
                matched = fuzzy_match(result, candidates, lookup_config.get("threshold", 0.8))
                if matched and matched != result:
                    steps.append({"type": "lookup", "result": matched})
                    result = matched
    if not steps:
        return result, None
    return result, {"raw": raw, "steps": steps, "final": result}


def normalize_at_path(data, path, field_config, config_dir=None):
    if not path or not data:
        return
    key, remaining = path[0], path[1:]
    if key not in data:
        return
    if not remaining:
        context = {k: v for k, v in data.items() if isinstance(v, str)} if field_config.get("lookup") else None
        if isinstance(data[key], str):
            data[key] = normalize_field(data[key], field_config, config_dir, context)
        elif isinstance(data[key], list):
            data[key] = [normalize_field(item, field_config, config_dir, context) if isinstance(item, str) else item for item in data[key]]
    elif isinstance(data[key], dict):
        normalize_at_path(data[key], remaining, field_config, config_dir)
    elif isinstance(data[key], list):
        for item in data[key]:
            if isinstance(item, dict):
                normalize_at_path(item, remaining, field_config, config_dir)


def normalize(data, config):
    norm_config = config.get("normalization") if config else None
    if not norm_config:
        return data
    if isinstance(data, list) and len(data) == 1 and isinstance(data[0], dict):
        data = data[0]
    if not isinstance(data, dict):
        return data
    result = data.copy()
    config_dir = config.get("_config_dir")
    for field_path, field_config in norm_config.items():
        normalize_at_path(result, field_path.split("."), field_config, config_dir)
    return result


def _traced_at_path(data, path, field_config, config_dir, prefix, traces):
    if not path or not data:
        return
    key, remaining = path[0], path[1:]
    if key not in data:
        return
    if not remaining:
        context = {k: v for k, v in data.items() if isinstance(v, str)} if field_config.get("lookup") else None
        if isinstance(data[key], str):
            val, trace = normalize_field_traced(data[key], field_config, config_dir, context)
            data[key] = val
            if trace:
                traces[prefix + key] = trace
        elif isinstance(data[key], list):
            for i, item in enumerate(data[key]):
                if isinstance(item, str):
                    val, trace = normalize_field_traced(item, field_config, config_dir, context)
                    data[key][i] = val
                    if trace:
                        traces[f"{prefix}{key}.{i}"] = trace
    elif isinstance(data[key], dict):
        _traced_at_path(data[key], remaining, field_config, config_dir, prefix + key + ".", traces)
    elif isinstance(data[key], list):
        for i, item in enumerate(data[key]):
            if isinstance(item, dict):
                _traced_at_path(item, remaining, field_config, config_dir, f"{prefix}{key}.{i}.", traces)


def normalize_traced(data, config):
    norm_config = config.get("normalization") if config else None
    if not norm_config:
        return data, {}
    if isinstance(data, list) and len(data) == 1 and isinstance(data[0], dict):
        data = data[0]
    if not isinstance(data, dict):
        return data, {}
    result = data.copy()
    config_dir = config.get("_config_dir")
    traces = {}
    for field_path, field_config in norm_config.items():
        _traced_at_path(result, field_path.split("."), field_config, config_dir, "", traces)
    return result, traces


def _parse_verify_response(raw_result):
    lines = [l.strip() for l in raw_result.strip().splitlines() if l.strip()]
    result = lines[-1] if lines else raw_result.strip()
    return result.strip('`"\'*')


def _verify_cache_path(config, pdf_path, llm, prompt):
    cdir = _cache_dir(config) / "verify"
    pdf_hash = _get_pdf_hash(pdf_path)
    prompt_hash = hashlib.md5(prompt.encode()).hexdigest()[:8]
    return cdir / f"{pdf_hash}_{llm.replace('/', '_')}_{prompt_hash}.json"


def _verify_at_path(data, path, verify_config, pdf_path, llm, prefix, traces, config=None):
    if not path or not data:
        return 0
    key, remaining = path[0], path[1:]
    if key not in data:
        return 0
    total_cost = 0
    if not remaining:
        if isinstance(data[key], str) and data[key]:
            prompt = verify_config["prompt"].replace("{value}", data[key])
            cache_file = _verify_cache_path(config, pdf_path, llm, prompt) if config else None
            if cache_file and cache_file.exists():
                with open(cache_file) as f:
                    result = json.load(f)["result"]
            else:
                raw_result, c = verify_with_llm(pdf_path, llm, prompt)
                total_cost += c
                result = _parse_verify_response(raw_result)
                if cache_file:
                    cache_file.parent.mkdir(parents=True, exist_ok=True)
                    with open(cache_file, "w") as f:
                        json.dump({"value": data[key], "result": result}, f)
            if result and result != data[key]:
                trace_key = prefix + key
                if trace_key not in traces:
                    traces[trace_key] = {"raw": data[key], "steps": [], "final": data[key]}
                traces[trace_key]["steps"].append({"type": "verify", "result": result})
                traces[trace_key]["final"] = result
                data[key] = result
    elif isinstance(data[key], dict):
        total_cost += _verify_at_path(data[key], remaining, verify_config, pdf_path, llm, prefix + key + ".", traces, config)
    elif isinstance(data[key], list):
        for i, item in enumerate(data[key]):
            if isinstance(item, dict):
                total_cost += _verify_at_path(item, remaining, verify_config, pdf_path, llm, f"{prefix}{key}.{i}.", traces, config)
    return total_cost


def verify_fields(data, config, pdf_path, llm, norm_traces=None):
    norm_config = config.get("normalization") if config else None
    if not norm_config:
        return 0
    if norm_traces is None:
        norm_traces = {}
    total_cost = 0
    for field_path, field_config in norm_config.items():
        verify_config = field_config.get("verify")
        if not verify_config or not verify_config.get("active", True):
            continue
        total_cost += _verify_at_path(data, field_path.split("."), verify_config, pdf_path, llm, "", norm_traces, config)
    return total_cost


# --- Schema-driven eval ---

def parse_eval_schema(config):
    if not config or "schema" not in config:
        return None
    props = config["schema"].get("properties", {})
    eval_cfg = config.get("evaluation", {})
    array_scoring = eval_cfg.get("array_scoring", {})
    sections = {}
    array_sections = {}
    array_penalty_fields = {}
    array_key_fields = {}
    for name, spec in props.items():
        if spec.get("type") == "object":
            sections[name] = list(spec.get("properties", {}).keys())
        elif spec.get("type") == "array":
            all_fields = list(spec.get("items", {}).get("properties", {}).keys())
            scoring_cfg = array_scoring.get(name, {})
            array_sections[name] = scoring_cfg.get("fields", all_fields)
            array_penalty_fields[name] = scoring_cfg.get("penalty_fields", array_sections[name])
            key_field = scoring_cfg.get("key_field")
            if key_field:
                array_key_fields[name] = key_field
    field_types = eval_cfg.get("field_types", {})
    return {
        "sections": sections,
        "array_sections": array_sections,
        "array_penalty_fields": array_penalty_fields,
        "array_key_fields": array_key_fields,
        "field_types": field_types,
    }


# --- Evaluation ---

def get_field_value(field_data):
    if isinstance(field_data, dict) and "value" in field_data:
        return field_data["value"], field_data.get("source", "pdf")
    return field_data, "pdf"


CITY_ABBREVS = {
    'MTG.': 'MEETING', 'MTG': 'MEETING',
    'MT.': 'MOUNT', 'MT': 'MOUNT',
    'ST.': 'SAINT', 'ST': 'SAINT',
    'FT.': 'FORT', 'FT': 'FORT',
    'PT.': 'POINT', 'PT': 'POINT',
}


def normalize_city(val):
    s = str(val).strip().upper()
    for abbr, full in CITY_ABBREVS.items():
        if abbr.endswith('.'):
            s = re.sub(r'\b' + re.escape(abbr), full, s)
        else:
            s = re.sub(r'\b' + re.escape(abbr) + r'\b', full, s)
    return s.replace(' ', '')


def dealer_names_match(a, b):
    if not a or not b:
        return False
    a_norm = re.sub(r"[^a-z0-9]", "", str(a).lower())
    b_norm = re.sub(r"[^a-z0-9]", "", str(b).lower())
    if a_norm in b_norm or b_norm in a_norm:
        return True
    a_tokens = set(re.sub(r"[^a-z0-9\s]", "", str(a).lower()).split())
    b_tokens = set(re.sub(r"[^a-z0-9\s]", "", str(b).lower()).split())
    stop = {"the", "and", "inc", "llc", "co", "dba", "of", "a", "an"}
    a_tokens -= stop
    b_tokens -= stop
    if not a_tokens or not b_tokens:
        return False
    overlap = len(a_tokens & b_tokens) / min(len(a_tokens), len(b_tokens))
    return overlap >= 0.5


def _norm_email(v):
    s = str(v).strip().upper().replace(' ', '')
    if '@' not in s:
        for domain in ['YAHOO', 'GMAIL', 'HOTMAIL', 'AOL', 'COMCAST', 'OUTLOOK', 'ICLOUD', 'SBCGLOBAL', 'BELLSOUTH', 'ATT']:
            idx = s.find(domain)
            if idx > 0:
                s = s[:idx] + '@' + s[idx:]
                break
    return s


def _norm_invoice(v):
    return re.sub(r'\s', '', str(v).strip().upper()).lstrip('0O')


def compare_field(extracted, expected, field_path, score_sources=None, field_types=None):
    score_sources = score_sources or ["pdf", "hitl"]
    field_types = field_types or {}
    ext_val, exp_raw = extracted, expected
    for key in field_path.split('.'):
        ext_val = ext_val.get(key) if isinstance(ext_val, dict) else None
        exp_raw = exp_raw.get(key) if isinstance(exp_raw, dict) else None
    exp_val, source = get_field_value(exp_raw)
    if source not in score_sources:
        return None, ext_val, exp_val, source, True
    if exp_val is None:
        return None, ext_val, exp_val, source, True
    if ext_val is None:
        return False, ext_val, exp_val, source, False

    field_name = field_path.split('.')[-1]
    ftype = field_types.get(field_name)

    if ftype == "date":
        if dates_equal(ext_val, exp_val):
            return True, ext_val, exp_val, source, False

    ext_norm = str(ext_val).strip().upper().replace('$', '').replace(',', '').replace(' ', '')
    exp_norm = str(exp_val).strip().upper().replace('$', '').replace(',', '').replace(' ', '')

    if ftype == "strip_leading_zeros":
        ext_norm = ext_norm.lstrip('0') or '0'
        exp_norm = exp_norm.lstrip('0') or '0'
    elif ftype == "city":
        ext_norm = normalize_city(ext_val)
        exp_norm = normalize_city(exp_val)
    elif ftype == "email":
        ext_norm = _norm_email(ext_norm)
        exp_norm = _norm_email(exp_norm)

    if ext_norm == exp_norm:
        return True, ext_val, exp_val, source, False

    if ftype == "fuzzy_name" and dealer_names_match(ext_val, exp_val):
        return True, ext_val, exp_val, source, False

    if ftype == "invoice_number":
        ext_parts = sorted(_norm_invoice(p) for p in str(ext_val).split('/'))
        exp_parts = sorted(_norm_invoice(p) for p in str(exp_val).split('/'))
        if ext_parts == exp_parts or set(ext_parts) & set(exp_parts):
            return True, ext_val, exp_val, source, False

    return False, ext_val, exp_val, source, False


def score_extraction(extracted, expected, score_sources=None, eval_schema=None):
    score_sources = score_sources or ["pdf", "hitl"]
    field_types = eval_schema.get("field_types", {}) if eval_schema else {}
    scores = {}
    if isinstance(extracted, list) and extracted:
        extracted = extracted[0]

    sections = eval_schema["sections"] if eval_schema else {}
    array_sections = eval_schema["array_sections"] if eval_schema else {}

    for section, fields in sections.items():
        for field in fields:
            match, ext, exp, source, skip = compare_field(extracted, expected, f'{section}.{field}', score_sources, field_types)
            scores[f'{section}.{field}'] = {'match': match, 'extracted': ext, 'expected': exp, 'source': source, 'skip': skip}

    array_key_fields = eval_schema.get("array_key_fields", {}) if eval_schema else {}

    for arr_name, arr_fields in array_sections.items():
        ext_items = extracted.get(arr_name, []) if extracted else []
        exp_items = expected.get(arr_name, []) if expected else []

        scores[f'{arr_name}.count'] = {'match': len(ext_items) == len(exp_items), 'extracted': len(ext_items), 'expected': len(exp_items)}

        def norm_val(v):
            s = str(v or '').strip().upper().replace('$', '').replace(',', '').replace(' ', '').replace('FD', '').lstrip('0') or '0'
            s = re.sub(r'\.0+$', '', s)
            return s

        def collect_field(products, field):
            vals, sources = [], []
            for p in products:
                raw = p.get(field)
                val, src = get_field_value(raw)
                vals.append(norm_val(val) if val else None)
                sources.append(src)
            return vals, sources

        # --- Pool-based matching (existing logic) ---
        field_pools = {}
        for field in arr_fields:
            ext_vals, _ = collect_field(ext_items, field)
            exp_vals, exp_srcs = collect_field(exp_items, field)
            exp_remaining = [v for v, src in zip(exp_vals, exp_srcs) if src in score_sources and v]
            field_pools[field] = {"ext": ext_vals, "exp": exp_vals, "exp_remaining": exp_remaining}

        pool_product_matches = []
        for i, ext_p in enumerate(ext_items):
            row = {}
            for field in arr_fields:
                ext_v = norm_val(ext_p.get(field))
                pool = field_pools[field]["exp_remaining"]
                is_empty = not ext_v or ext_v == '0'
                match = is_empty or ext_v in pool or not pool
                matched_expected = None
                if match and ext_v in pool:
                    matched_expected = ext_v
                    pool.remove(ext_v)
                row[field] = {
                    'match': match if not is_empty else is_empty,
                    'extracted': ext_p.get(field),
                    'expected': matched_expected,
                    'source': 'not_in_pdf' if is_empty else 'pdf',
                    'skip': is_empty
                }
            pool_product_matches.append(row)

        pool_unmatched = {}
        for field in arr_fields:
            remaining = field_pools[field]["exp_remaining"]
            pool_unmatched[field] = len([v for v in remaining if v and v != '0'])

        key_field = array_key_fields.get(arr_name)

        if key_field:
            # --- Key-based matching ---
            exp_by_key = {}
            for exp_p in exp_items:
                raw_key = exp_p.get(key_field)
                kval, ksrc = get_field_value(raw_key)
                if kval:
                    exp_by_key.setdefault(norm_val(kval), []).append(exp_p)

            def _pick_best(ext_p, candidates):
                if len(candidates) == 1:
                    return candidates.pop(0)
                best, best_score = None, -1
                for cand in candidates:
                    score = 0
                    for f in arr_fields:
                        ev = norm_val(ext_p.get(f))
                        cr = cand.get(f)
                        cv, _ = get_field_value(cr)
                        if ev and cv and ev == norm_val(cv):
                            score += 1
                    if score > best_score:
                        best_score, best = score, cand
                if best:
                    candidates.remove(best)
                return best

            key_product_matches = []
            matched_exp_indices = set()
            for i, ext_p in enumerate(ext_items):
                row = {}
                ext_key = norm_val(ext_p.get(key_field))
                candidates = exp_by_key.get(ext_key, []) if ext_key and ext_key != '0' else []
                matched_exp = _pick_best(ext_p, candidates) if candidates else None

                for field in arr_fields:
                    ext_v = norm_val(ext_p.get(field))
                    is_empty = not ext_v or ext_v == '0'

                    if is_empty:
                        row[field] = {
                            'match': True, 'extracted': ext_p.get(field),
                            'expected': None, 'source': 'not_in_pdf', 'skip': True
                        }
                    elif matched_exp:
                        exp_raw = matched_exp.get(field)
                        exp_val, src = get_field_value(exp_raw)
                        exp_normed = norm_val(exp_val) if exp_val else None
                        if src not in score_sources or not exp_val:
                            row[field] = {
                                'match': True, 'extracted': ext_p.get(field),
                                'expected': None, 'source': src, 'skip': True
                            }
                        else:
                            row[field] = {
                                'match': ext_v == exp_normed,
                                'extracted': ext_p.get(field),
                                'expected': exp_val if isinstance(exp_raw, dict) else exp_raw,
                                'source': src, 'skip': False
                            }
                    else:
                        row[field] = {
                            'match': False, 'extracted': ext_p.get(field),
                            'expected': None, 'source': 'pdf', 'skip': False
                        }

                if matched_exp:
                    matched_exp_indices.add(id(matched_exp))
                key_product_matches.append(row)

            key_unmatched = {}
            for field in arr_fields:
                count = 0
                for exp_p in exp_items:
                    if id(exp_p) not in matched_exp_indices:
                        fraw = exp_p.get(field)
                        fval, fsrc = get_field_value(fraw)
                        if fsrc in score_sources and fval and norm_val(fval) != '0':
                            count += 1
                key_unmatched[field] = count

            # Merge: key-based is primary, pool-based stored as pool_match
            merged = []
            for i in range(len(ext_items)):
                row = {}
                key_row = key_product_matches[i] if i < len(key_product_matches) else {}
                pool_row = pool_product_matches[i] if i < len(pool_product_matches) else {}
                for field in arr_fields:
                    entry = dict(key_row.get(field, {}))
                    entry['pool_match'] = pool_row.get(field, {}).get('match')
                    row[field] = entry
                merged.append(row)

            scores[arr_name] = merged
            scores[f'{arr_name}_unmatched'] = key_unmatched
            scores[f'{arr_name}_pool_unmatched'] = pool_unmatched
        else:
            scores[arr_name] = pool_product_matches
            scores[f'{arr_name}_unmatched'] = pool_unmatched

    return scores


def _tally_sections(scores, eval_schema):
    sections = eval_schema["sections"] if eval_schema else {}
    array_sections = eval_schema["array_sections"] if eval_schema else {}

    grand_correct, grand_total = 0, 0
    section_tallies = {}

    for section, fields in sections.items():
        correct, total, skipped = 0, 0, 0
        mismatches = []
        field_details = []
        for key, val in scores.items():
            if not key.startswith(f'{section}.'):
                continue
            field = key.split('.')[1]
            if val.get('skip'):
                skipped += 1
                field_details.append((field, val, True))
                continue
            if val['expected'] is None and (val['extracted'] is None or val['extracted'] == ''):
                continue
            if val['match']:
                correct += 1
            else:
                mismatches.append((field, val))
            total += 1
            field_details.append((field, val, False))
        section_tallies[section] = {
            "correct": correct, "total": total, "skipped": skipped,
            "mismatches": mismatches, "field_details": field_details,
        }
        grand_correct += correct
        grand_total += total

    for arr_name, arr_fields in array_sections.items():
        arr_correct, arr_total, arr_skipped = 0, 0, 0
        pool_correct, pool_total = 0, 0
        has_pool = False
        for p in scores.get(arr_name, []):
            for field in arr_fields:
                if field not in p:
                    continue
                if not p[field].get('skip'):
                    if p[field]['match']:
                        arr_correct += 1
                    arr_total += 1
                    if 'pool_match' in p[field]:
                        has_pool = True
                        pool_total += 1
                        if p[field]['pool_match']:
                            pool_correct += 1
                else:
                    arr_skipped += 1
                    if 'pool_match' in p[field]:
                        has_pool = True

        unmatched = scores.get(f'{arr_name}_unmatched', {})
        penalty_fields = eval_schema.get("array_penalty_fields", {}).get(arr_name, arr_fields) if eval_schema else arr_fields
        for f in penalty_fields:
            arr_total += unmatched.get(f, 0)

        tally = {
            "correct": arr_correct, "total": arr_total, "skipped": arr_skipped,
            "unmatched": unmatched, "rows": scores.get(arr_name, []),
            "arr_fields": arr_fields,
        }

        if has_pool:
            pool_unmatched = scores.get(f'{arr_name}_pool_unmatched', {})
            for f in penalty_fields:
                pool_total += pool_unmatched.get(f, 0)
            tally["pool_correct"] = pool_correct
            tally["pool_total"] = pool_total

        section_tallies[arr_name] = tally
        grand_correct += arr_correct
        grand_total += arr_total

    return grand_correct, grand_total, section_tallies


def _has_lookup(norm_traces, key):
    trace = norm_traces.get(key)
    if not trace:
        return False
    return any(s.get("type") == "lookup" for s in trace.get("steps", []))


def _score_style(pct):
    if pct >= 95:
        return "green"
    elif pct >= 80:
        return "yellow"
    return "red"


def _print_compact(scores, llm_name, eval_schema, norm_traces=None):
    grand_correct, grand_total, tallies = _tally_sections(scores, eval_schema)
    pct = 100 * grand_correct / grand_total if grand_total > 0 else 0

    sections = eval_schema["sections"] if eval_schema else {}
    array_sections = eval_schema["array_sections"] if eval_schema else {}

    style = _score_style(pct)
    console.print(f"\n  [{style}]{pct:.1f}%[/{style}] [dim]({grand_correct}/{grand_total})[/dim]")

    parts = []
    for name in list(sections) + list(array_sections):
        t = tallies[name]
        parts.append(f"{name} {t['correct']}/{t['total']}")
    console.print(f"  [dim]{' · '.join(parts)}[/dim]")

    for section in sections:
        for field, val in tallies[section]["mismatches"]:
            ext = escape(str(val['extracted'] or ''))
            exp = escape(str(val['expected'] or ''))
            console.print(f"  [red]✗ {section}.{field}:[/red] '{ext}' → '{exp}'")

    norm_traces = norm_traces or {}
    for arr_name in array_sections:
        t = tallies[arr_name]
        lookup_count = 0
        for i, p in enumerate(t["rows"]):
            for field in t["arr_fields"]:
                if field in p and not p[field].get('skip') and not p[field].get('match'):
                    ext = escape(str(p[field].get('extracted', '') or ''))
                    console.print(f"  [red]✗ {arr_name}\\[{i+1}].{field}:[/red] '{ext}'")
                if _has_lookup(norm_traces, f"{arr_name}.{i}.{field}"):
                    lookup_count += 1
        unmatched = t.get("unmatched", {})
        um_parts = [f for f in t["arr_fields"] if unmatched.get(f, 0)]
        if um_parts:
            console.print(f"  [yellow]⚠ {sum(unmatched[f] for f in um_parts)} unmatched: {', '.join(um_parts)}[/yellow]")
        if lookup_count:
            console.print(f"  [cyan]⇄ {lookup_count} lookup corrections[/cyan]")

    return grand_correct, grand_total


def _print_verbose(scores, llm_name, eval_schema, norm_traces=None):
    grand_correct, grand_total, tallies = _tally_sections(scores, eval_schema)
    pct = 100 * grand_correct / grand_total if grand_total > 0 else 0

    sections = eval_schema["sections"] if eval_schema else {}
    array_sections = eval_schema["array_sections"] if eval_schema else {}

    header = Text()
    header.append(f"{llm_name}", style="bold")
    header.append(f"  {pct:.1f}% ({grand_correct}/{grand_total})", style="dim")
    console.print()
    console.print(Panel(header, expand=True))

    for section in sections:
        t = tallies[section]
        console.print(f"\n [bold]{section.upper()}[/bold] {t['correct']}/{t['total']}")

        tbl = Table(show_header=False, box=None, padding=(0, 1))
        tbl.add_column("field", min_width=16)
        tbl.add_column("extracted", min_width=20)
        tbl.add_column("expected", min_width=20)
        tbl.add_column("", width=2)

        for field, val, skipped in t["field_details"]:
            if skipped:
                tbl.add_row(
                    Text(field, style="dim"), Text(str(val.get('extracted', '') or ''), style="dim"),
                    "", Text("⊘", style="dim"),
                )
                continue
            if val.get('match'):
                tbl.add_row(field, str(val.get('extracted', '') or ''), "", Text("✓", style="green"))
            else:
                tbl.add_row(
                    Text(field, style="red"), Text(str(val.get('extracted', '') or ''), style="red"),
                    Text(str(val.get('expected', '') or ''), style="dim"), Text("✗", style="red"),
                )
        console.print(tbl)

    norm_traces = norm_traces or {}
    for arr_name in array_sections:
        t = tallies[arr_name]
        console.print(f"\n [bold]{arr_name.upper()}[/bold] {t['correct']}/{t['total']}")

        tbl = Table(show_header=True, box=None, padding=(0, 1))
        tbl.add_column("#", width=4)
        tbl.add_column("field", min_width=16)
        tbl.add_column("extracted", min_width=18)
        tbl.add_column("expected", min_width=18)
        tbl.add_column("", width=2)

        lookup_count = 0
        for i, p in enumerate(t["rows"]):
            first = True
            for field in t["arr_fields"]:
                if field not in p:
                    continue
                idx_str = f"[{i+1}]" if first else ""
                first = False
                ext = str(p[field].get('extracted', '') or '')
                exp = str(p[field].get('expected', '') or '')
                has_lu = _has_lookup(norm_traces, f"{arr_name}.{i}.{field}")
                if has_lu:
                    lookup_count += 1

                if p[field].get('skip'):
                    tbl.add_row(idx_str, Text(field, style="dim"), Text(ext, style="dim"), "", Text("⊘", style="dim"))
                elif p[field].get('match'):
                    marker = Text("✓⇄", style="green") if has_lu else Text("✓", style="green")
                    tbl.add_row(idx_str, field, ext, "", marker)
                else:
                    marker = Text("✗⇄", style="red") if has_lu else Text("✗", style="red")
                    tbl.add_row(idx_str, Text(field, style="red"), Text(ext, style="red"), Text(exp, style="dim"), marker)

        console.print(tbl)

        unmatched = t.get("unmatched", {})
        um_parts = [f for f in t["arr_fields"] if unmatched.get(f, 0)]
        if um_parts:
            console.print(f" [yellow]⚠ {sum(unmatched[f] for f in um_parts)} unmatched: {', '.join(um_parts)}[/yellow]")
        if lookup_count:
            console.print(f" [cyan]⇄ {lookup_count} lookup corrections[/cyan]")

    console.print()
    return grand_correct, grand_total


def print_scores(scores, llm_name, eval_schema=None, verbose=False, norm_traces=None):
    if verbose:
        return _print_verbose(scores, llm_name, eval_schema, norm_traces)
    return _print_compact(scores, llm_name, eval_schema, norm_traces)


def _build_details(doc_id, llm, score, total, cost_val, scores, eval_schema=None, norm_traces=None):
    sections = eval_schema["sections"] if eval_schema else {}
    array_sections = eval_schema["array_sections"] if eval_schema else {}
    section_prefixes = tuple(f"{s}." for s in sections)
    norm_traces = norm_traces or {}

    _, _, tallies = _tally_sections(scores, eval_schema)

    details = {
        "doc_id": doc_id, "llm": llm,
        "accuracy": round(100 * score / total, 1) if total else 0,
        "score": score, "total": total, "cost": cost_val,
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "fields": {}
    }

    # Add pool_score/pool_total if any array section has pool data
    pool_score_sum, pool_total_sum, has_pool = 0, 0, False
    for arr_name in array_sections:
        t = tallies.get(arr_name, {})
        if "pool_correct" in t:
            has_pool = True
            pool_score_sum += t["pool_correct"]
            pool_total_sum += t["pool_total"]
    if has_pool:
        # Add non-array section scores to pool totals (they're the same for both)
        for section in sections:
            t = tallies.get(section, {})
            pool_score_sum += t.get("correct", 0)
            pool_total_sum += t.get("total", 0)
        details["pool_score"] = pool_score_sum
        details["pool_total"] = pool_total_sum
        details["pool_accuracy"] = round(100 * pool_score_sum / pool_total_sum, 1) if pool_total_sum else 0

    for key, val in scores.items():
        if key.startswith(section_prefixes):
            field_detail = {
                "match": val.get("match"),
                "extracted": val.get("extracted"),
                "expected": val.get("expected"),
                "skip": val.get("skip", False)
            }
            trace = norm_traces.get(key)
            if trace:
                field_detail["normalization"] = trace
            details["fields"][key] = field_detail
    for arr_name, arr_fields in array_sections.items():
        details[arr_name] = []
        for i, p in enumerate(scores.get(arr_name, [])):
            row = {}
            for field in arr_fields:
                if field in p:
                    field_detail = {
                        "match": p[field].get("match"),
                        "extracted": p[field].get("extracted"),
                        "expected": p[field].get("expected"),
                        "skip": p[field].get("skip", False)
                    }
                    if "pool_match" in p[field]:
                        field_detail["pool_match"] = p[field]["pool_match"]
                    trace = norm_traces.get(f"{arr_name}.{i}.{field}")
                    if trace:
                        field_detail["normalization"] = trace
                    row[field] = field_detail
            details[arr_name].append(row)
    return details


# --- Consensus ---

def norm_cell(value):
    s = " ".join(str(value).replace("\u2013", "-").replace("\u2014", "-").split())
    return s.rstrip(" -").lower().replace(",", "").replace(".", "")


def cell_agreement(results):
    if len(results) < 2:
        return 0.5
    all_rows = [r.get("rows", []) for r in results.values()]
    if not any(all_rows):
        return 0.0
    sample_size = min(5, min(len(rows) for rows in all_rows if rows) if any(all_rows) else 0)
    if sample_size == 0:
        return 0.0
    agreements = []
    for row_idx in range(sample_size):
        all_cols = set()
        for rows in all_rows:
            if row_idx < len(rows):
                all_cols.update(rows[row_idx].keys())
        for col in all_cols:
            values = []
            for rows in all_rows:
                if row_idx < len(rows) and col in rows[row_idx]:
                    values.append(norm_cell(rows[row_idx][col]))
            if len(values) >= 2:
                most_common = Counter(values).most_common(1)[0][1]
                agreements.append(most_common / len(values))
    return sum(agreements) / len(agreements) if agreements else 0.0


def calculate_confidence(results):
    if len(results) < 2:
        return 0.5
    scores = []
    row_counts = [len(r.get("rows", [])) for r in results.values()]
    if row_counts:
        most_common_count = Counter(row_counts).most_common(1)[0][1]
        scores.append(("row_count", 0.3, most_common_count / len(row_counts)))
    header_sets = []
    for r in results.values():
        rows = r.get("rows", [])
        if rows:
            header_sets.append(frozenset(rows[0].keys()))
    if len(header_sets) >= 2:
        common = set.intersection(*[set(h) for h in header_sets])
        all_h = set.union(*[set(h) for h in header_sets])
        scores.append(("headers", 0.3, len(common) / len(all_h) if all_h else 0))
    scores.append(("cells", 0.4, cell_agreement(results)))
    return sum(w * s for _, w, s in scores)


def build_consensus(results):
    if not results:
        return []
    base = max(results.values(), key=lambda r: len(r.get("rows", [])))
    base_rows = base.get("rows", [])
    if not base_rows:
        return []
    consensus = []
    for row_idx, base_row in enumerate(base_rows):
        row = {}
        for col in base_row.keys():
            values = []
            for r in results.values():
                rows = r.get("rows", [])
                if row_idx < len(rows) and col in rows[row_idx]:
                    values.append(rows[row_idx][col])
            if values:
                normalized = [norm_cell(v) for v in values]
                most_common_norm = Counter(normalized).most_common(1)[0][0]
                for v, n in zip(values, normalized):
                    if n == most_common_norm:
                        row[col] = v
                        break
            else:
                row[col] = base_row[col]
        consensus.append(row)
    return consensus


def consensus_field(values):
    if not values:
        return None
    valid = [v for v in values if v is not None]
    if not valid:
        return None
    normalized = [norm_cell(v) for v in valid]
    most_common_norm = Counter(normalized).most_common(1)[0][0]
    for v, n in zip(valid, normalized):
        if n == most_common_norm:
            return v
    return valid[0]


def build_full_consensus(results, eval_schema=None):
    if not results:
        return {}

    all_data = [r.get("data", {}) for r in results.values()]
    consensus = {}

    sections = eval_schema["sections"] if eval_schema else {}
    array_sections = eval_schema["array_sections"] if eval_schema else {}

    for section, fields in sections.items():
        consensus[section] = {}
        for field in fields:
            values = [d.get(section, {}).get(field) for d in all_data]
            consensus[section][field] = consensus_field(values)

    for arr_name in array_sections:
        consensus[arr_name] = build_consensus(results)

    return consensus


def _consensus_extract_one(pdf_path, llm, config, no_cache, eval_schema):
    """Extract for a single LLM in consensus mode. Returns (llm, result_dict) or raises."""
    cached, is_fallback = get_cached(pdf_path, llm, config)
    if cached and not no_cache:
        result = cached
        c = result.get("cost", 0)
        is_new = False
    else:
        result = extract(pdf_path, config, llm)
        set_cache(pdf_path, llm, config, result)
        c = result["cost"]
        is_new = True

    data = result["data"]
    if config and config.get("normalization"):
        data = normalize(data, config)
    if isinstance(data, list) and len(data) == 1:
        data = data[0]
    arr_name = list(eval_schema["array_sections"].keys())[0] if eval_schema and eval_schema.get("array_sections") else "products"
    rows = data.get(arr_name, []) if isinstance(data, dict) else data
    return {"data": data, "rows": rows, "cost": c, "is_new": is_new}


def run_consensus(pdf_path, config, llms, output_dir=None, no_cache=False, eval_schema=None, parallel=False):
    results = {}
    errors = []
    total_cost = 0

    avail = available_llms()
    avail_llms = [l for l in llms if l in avail]
    for l in llms:
        if l not in avail:
            errors.append(f"{l}: unavailable")

    if parallel:
        from concurrent.futures import ThreadPoolExecutor, as_completed

        futures = {}
        with ThreadPoolExecutor() as executor:
            for llm in avail_llms:
                fut = executor.submit(_consensus_extract_one, pdf_path, llm, config, no_cache, eval_schema)
                futures[fut] = llm

            for fut in as_completed(futures):
                llm = futures[fut]
                try:
                    r = fut.result()
                    results[llm] = {"data": r["data"], "rows": r["rows"], "cost": r["cost"]}
                    if r["is_new"]:
                        total_cost += r["cost"]
                except Exception as e:
                    errors.append(f"{llm}: {e}")
    else:
        for llm in avail_llms:
            try:
                r = _consensus_extract_one(pdf_path, llm, config, no_cache, eval_schema)
                results[llm] = {"data": r["data"], "rows": r["rows"], "cost": r["cost"]}
                if r["is_new"]:
                    total_cost += r["cost"]
            except Exception as e:
                errors.append(f"{llm}: {e}")

    if not results:
        return {"error": "No successful extractions", "flags": errors}

    consensus_data = build_full_consensus(results, eval_schema)
    confidence = calculate_confidence(results)

    return {
        "consensus": consensus_data.get(list(eval_schema["array_sections"].keys())[0] if eval_schema and eval_schema.get("array_sections") else "products", []),
        "consensus_data": consensus_data,
        "confidence": confidence,
        "extractors": list(results.keys()),
        "individual": {k: {"rows": len(v["rows"]), "cost": v["cost"], "data": v["data"]} for k, v in results.items()},
        "total_cost": total_cost,
        "errors": errors
    }


# --- Worker for single (pdf, llm) extraction ---

def _extract_one(pdf_path, doc_id, llm, config, eval_schema, gt, no_cache, raw, output):
    """Extract and evaluate a single (pdf, llm) pair. Returns a result dict, no printing."""
    info = {"llm": llm, "doc_id": doc_id, "error": None, "cost": 0,
            "cache_label": None, "data": None, "result": None,
            "norm_traces": {}, "field_scores": None, "score": None,
            "total": None, "details": None, "out_path": None, "raw_output": None,
            "norm_output": None, "summary_line": None}

    cached, is_fallback = get_cached(str(pdf_path), llm, config)
    if cached and not no_cache:
        result = cached
        data = result["data"]
        info["cache_label"] = "[CACHED-FALLBACK]" if is_fallback else "[CACHED]"
    else:
        result = extract(str(pdf_path), config, llm)
        data = result["data"]
        set_cache(str(pdf_path), llm, config, result)
        info["cost"] = result["cost"]

    info["result"] = result
    info["data"] = data

    if output:
        provider, model = llm.split("/", 1)
        out_dir = f"{output}/{provider}/{model}"
        os.makedirs(out_dir, exist_ok=True)
        out_path = f"{out_dir}/{doc_id}.json"
        out_data = {
            "data": data,
            "metadata": {
                "llm": llm,
                "input_tokens": result["input_tokens"],
                "output_tokens": result["output_tokens"],
                "cost": result["cost"],
                "timestamp": datetime.utcnow().isoformat() + "Z"
            }
        }
        with open(out_path, "w") as f:
            json.dump(out_data, f, indent=2)
        info["out_path"] = out_path

    if raw:
        info["raw_output"] = json.dumps(data, indent=2)[:2000]

    norm_traces = {}
    if config and config.get("normalization"):
        data, norm_traces = normalize_traced(data, config)
        info["data"] = data
        info["norm_traces"] = norm_traces
        if raw and isinstance(data, dict) and eval_schema:
            lines = []
            for arr_name, arr_fields in eval_schema.get("array_sections", {}).items():
                for item in data.get(arr_name, []):
                    lines.append(f"  {item.get(arr_fields[0]) if arr_fields else item}")
            info["norm_output"] = "\n".join(lines)

    verify_cost = verify_fields(data, config, str(pdf_path), llm, norm_traces)
    info["cost"] += verify_cost

    if gt:
        field_scores = score_extraction(data, gt, eval_schema=eval_schema)
        info["field_scores"] = field_scores
    return info


# --- Helpers ---

def _resolve_pdfs(pdf, config):
    pdfs = []
    if pdf:
        pdf_path = Path(pdf)
        if pdf_path.exists():
            pdfs = [pdf_path]
        else:
            stem = pdf_path.stem
            search_dirs = []
            if pdf_path.parent != Path(".") and pdf_path.parent.exists():
                search_dirs.append(pdf_path.parent)
            pdfs_dir = config.get("data", {}).get("pdfs") if config else None
            if pdfs_dir:
                search_dirs.append(Path(pdfs_dir))
            matches = []
            for d in search_dirs:
                matches = list(d.glob(f"{stem}*.[pP][dD][fF]"))
                if matches:
                    break
            if matches:
                pdfs = [matches[0]]
            else:
                raise ValueError(f"Not found: {pdf}")
    else:
        pdfs_dir = config.get("data", {}).get("pdfs") if config else None
        if not pdfs_dir:
            raise ValueError("No PDF specified and no data.pdfs directory in config")
        pdfs_dir = Path(pdfs_dir)
        if not pdfs_dir.exists():
            raise ValueError(f"PDFs directory not found: {pdfs_dir}")
        pdfs = sorted(pdfs_dir.glob("*.pdf")) + sorted(pdfs_dir.glob("*.PDF"))
        if not pdfs:
            raise ValueError(f"No PDFs found in {pdfs_dir}")
    return pdfs


def _load_ground_truth(ground_truth_path, config):
    gt_path = ground_truth_path or (config.get("data", {}).get("ground_truth") if config else None)
    if gt_path and Path(gt_path).exists():
        with open(gt_path) as f:
            return json.load(f)
    return None


def _error_info(llm, e):
    return {"llm": llm, "error": str(e), "cost": 0,
            "cache_label": None, "data": None, "result": None,
            "norm_traces": {}, "field_scores": None, "out_path": None,
            "raw_output": None, "norm_output": None}


# --- Batch orchestration (no printing) ---

def run_batch(config, pdfs, llms, eval_schema=None, gt_data=None,
              no_cache=False, raw=False, output=None, output_details=None,
              consensus=False, parallel=False):
    avail = available_llms()
    avail_llms = [l for l in llms if l in avail]
    unavail_llms = [l for l in llms if l not in avail]

    work_pdfs = []
    for pdf_path in pdfs:
        if not pdf_path.exists():
            continue
        doc_id = pdf_path.stem.split(' ')[0]
        gt = gt_data.get(doc_id) if gt_data else None
        work_pdfs.append((pdf_path, doc_id, gt))

    all_results = {}
    session_cost = 0

    if consensus:
        for pdf_path, doc_id, gt in work_pdfs:
            result = run_consensus(str(pdf_path), config, llms, output, no_cache, eval_schema, parallel=parallel)
            session_cost += result.get('total_cost', 0)

            doc_result = {
                "pdf_path": str(pdf_path),
                "consensus": result,
            }

            if gt and result.get('consensus_data'):
                consensus_data = result['consensus_data']
                field_scores = score_extraction(consensus_data, gt, eval_schema=eval_schema)
                score, total, tallies = _tally_sections(field_scores, eval_schema)
                doc_result["summary"] = {"consensus": {"score": score, "total": total, "pct": round(100 * score / total, 1) if total else 0}}
                doc_result["field_scores"] = field_scores

                if output_details:
                    details = _build_details(doc_id, "consensus", score, total, result['total_cost'], field_scores, eval_schema, {})
                    details["extractors"] = result.get('extractors', [])
                    with open(output_details, "a") as f:
                        f.write(json.dumps(details) + "\n")

            if output:
                os.makedirs(output, exist_ok=True)
                out_path = f"{output}/{doc_id}_consensus.json"
                with open(out_path, "w") as f:
                    json.dump(result, f, indent=2)

            all_results[doc_id] = doc_result
    elif parallel:
        from concurrent.futures import ThreadPoolExecutor, as_completed

        futures = {}
        with ThreadPoolExecutor() as executor:
            for pdf_path, doc_id, gt in work_pdfs:
                for llm in avail_llms:
                    fut = executor.submit(_extract_one, pdf_path, doc_id, llm, config, eval_schema, gt, no_cache, raw, output)
                    futures[fut] = (pdf_path, doc_id, gt, llm)

            completed = {}
            for fut in as_completed(futures):
                pdf_path, doc_id, gt, llm = futures[fut]
                try:
                    completed[(doc_id, llm)] = fut.result()
                except Exception as e:
                    completed[(doc_id, llm)] = _error_info(llm, e)

        for pdf_path, doc_id, gt in work_pdfs:
            doc_result = {"pdf_path": str(pdf_path), "extractions": {}, "summary": {}}
            for llm in avail_llms:
                info = completed[(doc_id, llm)]
                doc_result["extractions"][llm] = info
                session_cost += info["cost"]
                if gt and info.get("field_scores"):
                    score, total, _ = _tally_sections(info["field_scores"], eval_schema)
                    doc_result["summary"][llm] = {"score": score, "total": total, "pct": round(100 * score / total, 1) if total else 0}
                    if output_details:
                        details = _build_details(doc_id, llm, score, total, info.get("result", {}).get("cost", 0), info["field_scores"], eval_schema, info.get("norm_traces"))
                        with open(output_details, "a") as f:
                            f.write(json.dumps(details) + "\n")
            all_results[doc_id] = doc_result
    else:
        for pdf_path, doc_id, gt in work_pdfs:
            doc_result = {"pdf_path": str(pdf_path), "extractions": {}, "summary": {}}
            for llm in avail_llms:
                try:
                    info = _extract_one(pdf_path, doc_id, llm, config, eval_schema, gt, no_cache, raw, output)
                except Exception as e:
                    info = _error_info(llm, e)
                doc_result["extractions"][llm] = info
                session_cost += info["cost"]
                if gt and info.get("field_scores"):
                    score, total, _ = _tally_sections(info["field_scores"], eval_schema)
                    doc_result["summary"][llm] = {"score": score, "total": total, "pct": round(100 * score / total, 1) if total else 0}
                    if output_details:
                        details = _build_details(doc_id, llm, score, total, info.get("result", {}).get("cost", 0), info["field_scores"], eval_schema, info.get("norm_traces"))
                        with open(output_details, "a") as f:
                            f.write(json.dumps(details) + "\n")
            all_results[doc_id] = doc_result

    return {
        "results": all_results,
        "session_cost": session_cost,
        "eval_schema": eval_schema,
        "unavailable_llms": unavail_llms,
    }


# --- Presentation ---

def _print_info(info, gt, eval_schema, verbose, raw):
    llm = info["llm"]
    if info.get("error"):
        console.print(f"\n  [red]{escape(llm)}: ERROR - {escape(str(info['error']))}[/red]")
        return None

    cost_part = f"[dim]{info['cache_label']}[/dim]" if info.get("cache_label") else f"[dim]${info['cost']:.4f}[/dim]"
    saved_part = f" [dim]→ {escape(info['out_path'])}[/dim]" if info.get("out_path") else ""
    console.print(f"\n  [bold]{escape(llm)}[/bold]  {cost_part}{saved_part}")

    if raw and info.get("raw_output"):
        console.rule(f"[dim]RAW: {escape(llm)}[/dim]")
        console.print(info["raw_output"])

    if raw and info.get("norm_output"):
        console.rule("[dim]NORMALIZED[/dim]")
        console.print(info["norm_output"])

    if gt and info.get("field_scores"):
        score, total_possible = print_scores(info["field_scores"], llm, eval_schema, verbose=verbose, norm_traces=info.get("norm_traces"))
        return {'score': score, 'total': total_possible, 'pct': 100 * score / total_possible}
    elif not gt:
        data = info.get("data")
        if isinstance(data, dict) and eval_schema:
            for arr_name in eval_schema.get("array_sections", {}):
                console.print(f"  [dim]{len(data.get(arr_name, []))} {arr_name}[/dim]")
        else:
            console.print(f"  [dim]{len(data) if isinstance(data, list) else '?'} items[/dim]")
    return None


def _print_summary(results):
    scored = [(llm, r) for llm, r in sorted(results.items(), key=lambda x: -x[1].get('pct', 0)) if 'pct' in r]
    if not scored:
        return
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("LLM")
    table.add_column("Score", justify="right")
    for llm, r in scored:
        style = _score_style(r['pct'])
        table.add_row(escape(llm), f"[{style}]{r['pct']:.1f}%[/{style}] ({r['score']}/{r['total']})")
    console.print(Panel(table, title="Summary", expand=False))


def _print_batch_results(batch, pdfs, eval_schema, gt_data, verbose, raw, consensus_mode):
    for pdf_path in pdfs:
        doc_id = pdf_path.stem.split(' ')[0]
        doc_result = batch["results"].get(doc_id)
        if not doc_result:
            continue

        console.rule(f"[bold]{escape(pdf_path.name)}[/bold]")

        gt = gt_data.get(doc_id) if gt_data else None
        if gt and eval_schema:
            for arr_name in eval_schema.get("array_sections", {}):
                console.print(f"  [dim]ground truth {arr_name}: {len(gt.get(arr_name, []))}[/dim]")

        if consensus_mode:
            result = doc_result.get("consensus", {})
            console.print(f"\n  Confidence: [bold]{result.get('confidence', 0):.2f}[/bold]")
            console.print(f"  Extractors: {', '.join(result.get('extractors', []))}")
            console.print(f"  Consensus rows: {len(result.get('consensus', []))}")
            for k, v in result.get('individual', {}).items():
                console.print(f"    [dim]{escape(k)}: {v['rows']} rows, ${v['cost']:.4f}[/dim]")
            if result.get('errors'):
                console.print(f"  [red]Errors: {escape(str(result['errors']))}[/red]")
            console.print(f"  Total cost: [bold]${result.get('total_cost', 0):.4f}[/bold]")

            if doc_result.get("field_scores"):
                print_scores(doc_result["field_scores"], "consensus", eval_schema, verbose=verbose)
            continue

        has_gt = bool(gt)
        extractions = doc_result.get("extractions", {})

        results = {}
        for llm, info in extractions.items():
            score_info = _print_info(info, has_gt, eval_schema, verbose, raw)
            if score_info:
                results[llm] = score_info
            elif not has_gt:
                results[llm] = {}

        if results:
            _print_summary(results)


# --- Main entry point ---

def run(pdf=None, config=None, llms=None, all_llms=False, consensus=False,
        raw=False, no_cache=False, output=None, output_details=None,
        ground_truth_path=None, verbose=False, parallel=False):
    """Main extraction + eval loop. Called by CLI."""
    eval_schema = parse_eval_schema(config)

    if all_llms:
        llms = available_llms()
    if not llms:
        console.print("[red]No LLMs specified. Use --llm or --all[/red]")
        return 1

    try:
        pdfs = _resolve_pdfs(pdf, config)
    except ValueError as e:
        console.print(f"[red]{escape(str(e))}[/red]")
        return 1

    if not pdf:
        console.print(f"\n[bold]Batch mode:[/bold] {len(pdfs)} PDFs")

    gt_data = _load_ground_truth(ground_truth_path, config)

    if not output and config:
        output = config.get("data", {}).get("outputs")
    if not output_details and config:
        output_details = config.get("data", {}).get("eval_details")

    avail = available_llms()
    unavail_llms = [l for l in llms if l not in avail]
    if unavail_llms:
        for l in unavail_llms:
            console.print(f"  [yellow]{escape(l)}[/yellow] [dim]unavailable (missing API key)[/dim]")

    batch = run_batch(
        config=config, pdfs=pdfs, llms=llms, eval_schema=eval_schema,
        gt_data=gt_data, no_cache=no_cache, raw=raw, output=output,
        output_details=output_details, consensus=consensus, parallel=parallel,
    )

    _print_batch_results(batch, pdfs, eval_schema, gt_data, verbose, raw, consensus)

    if len(pdfs) > 1:
        console.rule(f"[bold]Batch complete: {len(pdfs)} PDFs[/bold]")

    session_cost = batch["session_cost"]
    console.print(f"\n  Session cost: [bold]${session_cost:.4f}[/bold]" + (" [dim](all cached)[/dim]" if session_cost == 0 else ""))
    return 0
